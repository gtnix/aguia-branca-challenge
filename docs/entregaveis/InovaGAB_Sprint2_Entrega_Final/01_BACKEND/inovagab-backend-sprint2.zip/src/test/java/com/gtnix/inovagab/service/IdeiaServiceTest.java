package com.gtnix.inovagab.service;

import com.gtnix.inovagab.document.IdeiaDocument;
import com.gtnix.inovagab.document.OrientacaoDocument;
import com.gtnix.inovagab.document.UsuarioDocument;
import com.gtnix.inovagab.domain.PerfilUsuario;
import com.gtnix.inovagab.domain.StatusIdeia;
import com.gtnix.inovagab.dto.ai.IdeaScoreItem;
import com.gtnix.inovagab.dto.ideia.AvaliacaoRequest;
import com.gtnix.inovagab.dto.ideia.IdeiaRequest;
import com.gtnix.inovagab.dto.ideia.PrioridadeRequest;
import com.gtnix.inovagab.repository.IdeiaRepository;
import com.gtnix.inovagab.repository.UsuarioRepository;
import com.gtnix.inovagab.security.UsuarioPrincipal;
import com.gtnix.inovagab.web.ApiException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IdeiaServiceTest {

    @Mock
    private IdeiaRepository ideiaRepository;
    @Mock
    private OrientacaoService orientacaoService;
    @Mock
    private UsuarioRepository usuarioRepository;

    private IdeiaService service;

    @BeforeEach
    void setUp() {
        service = new IdeiaService(ideiaRepository, orientacaoService, usuarioRepository);
        lenient().when(usuarioRepository.findById(any())).thenAnswer(invocation ->
                Optional.of(usuarioComNome(invocation.getArgument(0))));
        lenient().when(usuarioRepository.findAllById(any())).thenAnswer(invocation -> {
            Iterable<String> ids = invocation.getArgument(0);
            List<UsuarioDocument> users = new ArrayList<>();
            ids.forEach(id -> users.add(usuarioComNome(id)));
            return users;
        });
    }

    @Test
    void criarExigeOrientacaoAtivaEPersisteAutor() {
        when(orientacaoService.requireAtiva("ori-1")).thenReturn(new OrientacaoDocument());
        when(ideiaRepository.save(any())).thenAnswer(invocation -> {
            IdeiaDocument doc = invocation.getArgument(0);
            doc.setId("ideia-1");
            return doc;
        });

        var response = service.criar(request("ori-1"), principal(PerfilUsuario.OPERADOR));

        assertEquals("ideia-1", response.id());
        assertEquals("user-operador", response.autorUserId());
        assertEquals("Pedro Santos", response.autorNome());
        assertEquals("ori-1", response.orientacaoId());
        assertEquals(StatusIdeia.PENDENTE, response.status());
    }

    @Test
    void criarComOrientacaoInativaPropaga400() {
        when(orientacaoService.requireAtiva("ori-inativa"))
                .thenThrow(new ApiException(HttpStatus.BAD_REQUEST, "Orientação estratégica inválida ou inativa"));

        ApiException ex = assertThrows(ApiException.class,
                () -> service.criar(request("ori-inativa"), principal(PerfilUsuario.OPERADOR)));
        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatus());
    }

    @Test
    void operadorListaApenasAsProprias() {
        when(ideiaRepository.findByAutorUserIdAndAtivoTrue("user-operador"))
                .thenReturn(List.of(ideia("ideia-1", "user-operador")));

        var lista = service.listar(principal(PerfilUsuario.OPERADOR), null, null, null);

        assertEquals(1, lista.size());
        assertEquals("ideia-1", lista.get(0).id());
        assertEquals("Pedro Santos", lista.get(0).autorNome());
    }

    @Test
    void gestorListaTodas() {
        when(ideiaRepository.findByAtivoTrue()).thenReturn(List.of(
                ideia("ideia-1", "user-operador"),
                ideia("ideia-2", "user-outro")
        ));

        var lista = service.listar(principal(PerfilUsuario.GESTOR), null, null, null);

        assertEquals(2, lista.size());
    }

    @Test
    void operadorNaoEditaIdeiaDeTerceiro() {
        when(ideiaRepository.findByIdAndAtivoTrue("ideia-2"))
                .thenReturn(Optional.of(ideia("ideia-2", "user-outro")));

        ApiException ex = assertThrows(ApiException.class,
                () -> service.atualizar("ideia-2", request("ori-1"), principal(PerfilUsuario.OPERADOR)));
        assertEquals(HttpStatus.FORBIDDEN, ex.getStatus());
    }

    @Test
    void excluirFazSoftDeleteDaPropria() {
        IdeiaDocument doc = ideia("ideia-1", "user-operador");
        when(ideiaRepository.findByIdAndAtivoTrue("ideia-1")).thenReturn(Optional.of(doc));
        when(ideiaRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        service.excluir("ideia-1", principal(PerfilUsuario.OPERADOR));

        ArgumentCaptor<IdeiaDocument> captor = ArgumentCaptor.forClass(IdeiaDocument.class);
        verify(ideiaRepository).save(captor.capture());
        assertFalse(captor.getValue().isAtivo());
    }

    @Test
    void excluirIdeiaAprovadaRetorna400() {
        IdeiaDocument doc = ideia("ideia-1", "user-operador");
        doc.setStatus(StatusIdeia.APROVADA);
        when(ideiaRepository.findByIdAndAtivoTrue("ideia-1")).thenReturn(Optional.of(doc));

        ApiException ex = assertThrows(ApiException.class,
                () -> service.excluir("ideia-1", principal(PerfilUsuario.OPERADOR)));
        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatus());
    }

    @Test
    void obterInexistenteRetorna404() {
        when(ideiaRepository.findByIdAndAtivoTrue("sumiu")).thenReturn(Optional.empty());

        ApiException ex = assertThrows(ApiException.class,
                () -> service.obter("sumiu", principal(PerfilUsuario.GESTOR)));
        assertEquals(HttpStatus.NOT_FOUND, ex.getStatus());
    }

    @Test
    void operadorNaoObtemIdeiaDeTerceiro() {
        when(ideiaRepository.findByIdAndAtivoTrue("ideia-2"))
                .thenReturn(Optional.of(ideia("ideia-2", "user-outro")));

        ApiException ex = assertThrows(ApiException.class,
                () -> service.obter("ideia-2", principal(PerfilUsuario.OPERADOR)));
        assertEquals(HttpStatus.FORBIDDEN, ex.getStatus());
    }

    @Test
    void gestorAprovaIdeiaPendente() {
        IdeiaDocument doc = ideia("ideia-1", "user-operador");
        when(ideiaRepository.findByIdAndAtivoTrue("ideia-1")).thenReturn(Optional.of(doc));
        when(ideiaRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        var response = service.avaliar("ideia-1", new AvaliacaoRequest(StatusIdeia.APROVADA, null));

        assertEquals(StatusIdeia.APROVADA, response.status());
        assertNull(response.feedbackReprovacao());
        assertNotNull(doc.getDataAvaliacao());
    }

    @Test
    void reprovarSemFeedbackRetorna400() {
        ApiException ex = assertThrows(ApiException.class,
                () -> service.avaliar("ideia-1", new AvaliacaoRequest(StatusIdeia.REPROVADA, "  ")));
        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatus());
    }

    @Test
    void naoReavaliaIdeiaJaAprovada() {
        IdeiaDocument doc = ideia("ideia-1", "user-operador");
        doc.setStatus(StatusIdeia.APROVADA);
        when(ideiaRepository.findByIdAndAtivoTrue("ideia-1")).thenReturn(Optional.of(doc));

        ApiException ex = assertThrows(ApiException.class,
                () -> service.avaliar("ideia-1", new AvaliacaoRequest(StatusIdeia.REPROVADA, "fora")));
        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatus());
    }

    @Test
    void gestorPriorizaIdeiaPendente() {
        IdeiaDocument doc = ideia("ideia-1", "user-operador");
        when(ideiaRepository.findByIdAndAtivoTrue("ideia-1")).thenReturn(Optional.of(doc));
        when(ideiaRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        var response = service.priorizar("ideia-1", new PrioridadeRequest(80));

        assertEquals(80, response.prioridade());
    }

    @Test
    void persistirScoresGravaRecomendacaoSemAprovar() {
        IdeiaDocument doc = ideia("ideia-1", "user-operador");
        when(ideiaRepository.findByIdAndAtivoTrue("ideia-1")).thenReturn(Optional.of(doc));
        when(ideiaRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));

        service.persistirScores(
                List.of(new IdeaScoreItem("ideia-1", 140, "Alto alinhamento")),
                "heuristic-local",
                true
        );

        assertEquals(100, doc.getScoreIa());
        assertEquals("Alto alinhamento", doc.getJustificativaIa());
        assertTrue(doc.getScoreIaFallback());
        assertEquals(StatusIdeia.PENDENTE, doc.getStatus());
    }

    private static IdeiaRequest request(String orientacaoId) {
        return new IdeiaRequest("Título", "Descrição", "IDEIA", "OPERACOES", orientacaoId, 3, 2);
    }

    private static IdeiaDocument ideia(String id, String autor) {
        IdeiaDocument doc = new IdeiaDocument();
        doc.setId(id);
        doc.setAutorUserId(autor);
        doc.setTitulo("Título");
        doc.setOrientacaoId("ori-1");
        doc.setStatus(StatusIdeia.PENDENTE);
        doc.setDataCriacao(java.time.Instant.parse("2026-01-01T00:00:00Z"));
        return doc;
    }

    private static UsuarioDocument usuarioComNome(String id) {
        UsuarioDocument usuario = new UsuarioDocument();
        usuario.setId(id);
        usuario.setNome("user-operador".equals(id) ? "Pedro Santos" : "Usuário " + id);
        return usuario;
    }

    private static UsuarioPrincipal principal(PerfilUsuario perfil) {
        UsuarioDocument usuario = new UsuarioDocument();
        usuario.setId("user-" + perfil.name().toLowerCase());
        usuario.setEmail(perfil.name().toLowerCase() + "@aguiabranca.com.br");
        usuario.setSenhaHash("hash");
        usuario.setPerfil(perfil);
        usuario.setAtivo(true);
        return new UsuarioPrincipal(usuario);
    }
}
