package com.gtnix.inovagab.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gtnix.inovagab.config.GeminiProperties;
import com.gtnix.inovagab.document.IdeiaDocument;
import com.gtnix.inovagab.document.OrientacaoDocument;
import com.gtnix.inovagab.dto.ai.DashboardNarrativeResponse;
import com.gtnix.inovagab.dto.ai.ScoreIdeasRequest;
import com.gtnix.inovagab.dto.ai.ScoreIdeasResponse;
import com.gtnix.inovagab.dto.dashboard.DashboardSummaryResponse;
import com.gtnix.inovagab.web.ApiException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AiScoreServiceTest {

    @Mock
    private GeminiProperties geminiProperties;
    @Mock
    private IdeiaService ideiaService;
    @Mock
    private OrientacaoService orientacaoService;
    @Mock
    private DashboardService dashboardService;
    @Mock
    private GeminiClient geminiClient;

    private AiScoreService service;

    @BeforeEach
    void setUp() {
        service = new AiScoreService(
                geminiProperties,
                ideiaService,
                orientacaoService,
                dashboardService,
                new ObjectMapper(),
                geminiClient
        );
    }

    @Test
    void semChaveUsaFallbackEPersisteSemAprovar() {
        when(geminiProperties.isConfigured()).thenReturn(false);
        when(orientacaoService.requireAtiva("ori-1")).thenReturn(new OrientacaoDocument());
        when(ideiaService.findPendentesByIds(List.of("a", "b"), "ori-1")).thenReturn(List.of(
                pendente("a", 5, 1),
                pendente("b", 2, 4)
        ));

        ScoreIdeasResponse response = service.score(new ScoreIdeasRequest("ori-1", List.of("a", "b")));

        assertTrue(response.fallback());
        assertEquals(AiScoreService.MODELO_HEURISTICO, response.modelo());
        assertEquals("a", response.ranking().get(0).ideiaId());
        assertTrue(response.ranking().get(0).score() > response.ranking().get(1).score());
        assertFallbackJustificativa(response.ranking().get(0).justificativa());
        verify(ideiaService).persistirScores(eq(response.ranking()), eq(AiScoreService.MODELO_HEURISTICO), eq(true));
        verify(geminiClient, never()).generateContent(any(), any(), any());
    }

    @Test
    void geminiConfiguradoMasFalhaUsaFallbackHeuristico() {
        when(geminiProperties.isConfigured()).thenReturn(true);
        when(orientacaoService.requireAtiva("ori-1")).thenReturn(orientacao());
        when(ideiaService.findPendentesByIds(List.of("a"), "ori-1")).thenReturn(List.of(pendente("a", 5, 1)));
        when(geminiClient.generateContent(any(), any(), any())).thenThrow(new RuntimeException("timeout"));

        ScoreIdeasResponse response = service.score(new ScoreIdeasRequest("ori-1", List.of("a")));

        assertTrue(response.fallback());
        assertEquals(AiScoreService.MODELO_HEURISTICO, response.modelo());
        assertEquals("a", response.ranking().get(0).ideiaId());
        assertFallbackJustificativa(response.ranking().get(0).justificativa());
        verify(ideiaService).persistirScores(eq(response.ranking()), eq(AiScoreService.MODELO_HEURISTICO), eq(true));
    }

    @Test
    void geminiSucessoPersisteSemAprovarENaoColocaChaveNaUrl() {
        when(geminiProperties.isConfigured()).thenReturn(true);
        when(geminiProperties.getModel()).thenReturn("gemini-3.6-flash");
        when(geminiProperties.getApiKey()).thenReturn("test-key");
        when(orientacaoService.requireAtiva("ori-1")).thenReturn(orientacao());
        when(ideiaService.findPendentesByIds(List.of("a"), "ori-1")).thenReturn(List.of(pendente("a", 5, 1)));
        when(geminiClient.generateContent(eq("gemini-3.6-flash"), eq("test-key"), any()))
                .thenReturn("""
                        {"candidates":[{"content":{"parts":[{"text":"[{\\"ideiaId\\":\\"a\\",\\"score\\":88,\\"justificativa\\":\\"Alinhada\\"}]"}]}}]}
                        """);

        ScoreIdeasResponse response = service.score(new ScoreIdeasRequest("ori-1", List.of("a")));

        assertFalse(response.fallback());
        assertEquals("gemini-3.6-flash", response.modelo());
        assertEquals(88, response.ranking().get(0).score());
        ArgumentCaptor<String> promptCaptor = ArgumentCaptor.forClass(String.class);
        verify(geminiClient).generateContent(eq("gemini-3.6-flash"), eq("test-key"), promptCaptor.capture());
        assertFalse(promptCaptor.getValue().contains("test-key"));
        assertTrue(GeminiClient.GENERATE_URL_PREFIX.startsWith("https://generativelanguage.googleapis.com/"));
        assertFalse(GeminiClient.GENERATE_URL_PREFIX.contains("key="));
        verify(ideiaService).persistirScores(eq(response.ranking()), eq("gemini-3.6-flash"), eq(false));
    }

    @Test
    void semIdeiasPendentesRetorna400() {
        when(orientacaoService.requireAtiva("ori-1")).thenReturn(new OrientacaoDocument());
        when(ideiaService.findPendentesByIds(any(), any())).thenReturn(List.of());

        ApiException ex = assertThrows(ApiException.class,
                () -> service.score(new ScoreIdeasRequest("ori-1", List.of("a"))));
        assertEquals(HttpStatus.BAD_REQUEST, ex.getStatus());
    }

    private static OrientacaoDocument orientacao() {
        OrientacaoDocument doc = new OrientacaoDocument();
        doc.setTitulo("Eficiência");
        doc.setCampanha("Águia 2026");
        return doc;
    }

    private static IdeiaDocument pendente(String id, int impacto, int esforco) {
        IdeiaDocument doc = new IdeiaDocument();
        doc.setId(id);
        doc.setTitulo("Ideia " + id);
        doc.setImpacto(impacto);
        doc.setEsforco(esforco);
        return doc;
    }

    // ---- narrativaDashboard ----

    @Test
    void narrativaSemChaveRetornaFallbackEstruturado() {
        when(geminiProperties.isConfigured()).thenReturn(false);
        when(dashboardService.summary(isNull())).thenReturn(summaryComDados());

        DashboardNarrativeResponse resp = service.narrativaDashboard();

        assertTrue(resp.fallback());
        assertEquals(AiScoreService.MODELO_HEURISTICO, resp.modelo());
        assertNotNull(resp.titulo());
        assertFalse(resp.titulo().isBlank());
        assertNotNull(resp.resumo());
        assertFalse(resp.resumo().isBlank());
        assertNotNull(resp.acaoRecomendada());
        assertNotNull(resp.evidencias());
        assertNotNull(resp.geradoEm());
    }

    @Test
    void narrativaComFiltroOrientacaoPassaIdAoService() {
        when(geminiProperties.isConfigured()).thenReturn(false);
        when(dashboardService.summary("ori-1")).thenReturn(summaryComDados());

        DashboardNarrativeResponse resp = service.narrativaDashboard("ori-1");

        assertTrue(resp.fallback());
        verify(dashboardService).summary("ori-1");
    }

    @Test
    void narrativaGeminiSucessoRetornaEstruturado() throws Exception {
        when(geminiProperties.isConfigured()).thenReturn(true);
        when(geminiProperties.getModel()).thenReturn("gemini-3.6-flash");
        when(geminiProperties.getApiKey()).thenReturn("test-key");
        when(dashboardService.summary(isNull())).thenReturn(summaryComDados());
        String geminiJson = """
                {"candidates":[{"content":{"parts":[{"text":"{\\"titulo\\":\\"ROI sólido\\",\\"resumo\\":\\"Portfólio com 5 ideias e ROI de 20%.\\",\\"evidencias\\":[\\"ROI de 20%\\"],\\"acaoRecomendada\\":\\"Converter ideias.\\"}"}]}}]}
                """;
        when(geminiClient.generateContent(eq("gemini-3.6-flash"), eq("test-key"), any()))
                .thenReturn(geminiJson);

        DashboardNarrativeResponse resp = service.narrativaDashboard();

        assertFalse(resp.fallback());
        assertEquals("gemini-3.6-flash", resp.modelo());
        assertEquals("ROI sólido", resp.titulo());
        assertFalse(resp.evidencias().isEmpty());
    }

    @Test
    void narrativaGeminiJsonInvalidoUsaFallback() {
        when(geminiProperties.isConfigured()).thenReturn(true);
        when(geminiProperties.getModel()).thenReturn("gemini-3.6-flash");
        when(geminiProperties.getApiKey()).thenReturn("test-key");
        when(dashboardService.summary(isNull())).thenReturn(summaryComDados());
        when(geminiClient.generateContent(any(), any(), any())).thenReturn(
                "{\"candidates\":[{\"content\":{\"parts\":[{\"text\":\"resposta inválida sem JSON\"}]}}]}"
        );

        DashboardNarrativeResponse resp = service.narrativaDashboard();

        assertTrue(resp.fallback());
        assertEquals(AiScoreService.MODELO_HEURISTICO, resp.modelo());
    }

    private static DashboardSummaryResponse summaryComDados() {
        return new DashboardSummaryResponse(
                BigDecimal.valueOf(20),
                BigDecimal.valueOf(30_000),
                BigDecimal.valueOf(500_000),
                BigDecimal.valueOf(50_000),
                4,
                0,
                BigDecimal.valueOf(40),
                5,
                3,
                2,
                4,
                3,
                List.of(),
                List.of()
        );
    }

    private static void assertFallbackJustificativa(String justificativa) {
        assertEquals(AiScoreService.FALLBACK_JUSTIFICATIVA_PT, justificativa);
        assertFalse(justificativa.toUpperCase().contains("GEMINI"));
        assertFalse(justificativa.toLowerCase().contains("heurístico"));
        assertFalse(justificativa.contains("GEMINI_API_KEY"));
    }
}
