package com.gtnix.inovagab.service;

import com.gtnix.inovagab.document.IdeiaDocument;
import com.gtnix.inovagab.document.UsuarioDocument;
import com.gtnix.inovagab.domain.PerfilUsuario;
import com.gtnix.inovagab.domain.StatusIdeia;
import com.gtnix.inovagab.dto.ai.IdeaScoreItem;
import com.gtnix.inovagab.dto.ideia.AvaliacaoRequest;
import com.gtnix.inovagab.dto.ideia.IdeiaRequest;
import com.gtnix.inovagab.dto.ideia.IdeiaResponse;
import com.gtnix.inovagab.dto.ideia.PrioridadeRequest;
import com.gtnix.inovagab.repository.IdeiaRepository;
import com.gtnix.inovagab.repository.UsuarioRepository;
import com.gtnix.inovagab.security.UsuarioPrincipal;
import com.gtnix.inovagab.web.ApiException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;

@Service
public class IdeiaService {

    private final IdeiaRepository ideiaRepository;
    private final OrientacaoService orientacaoService;
    private final UsuarioRepository usuarioRepository;

    public IdeiaService(
            IdeiaRepository ideiaRepository,
            OrientacaoService orientacaoService,
            UsuarioRepository usuarioRepository
    ) {
        this.ideiaRepository = ideiaRepository;
        this.orientacaoService = orientacaoService;
        this.usuarioRepository = usuarioRepository;
    }

    public List<IdeiaResponse> listar(
            UsuarioPrincipal principal,
            StatusIdeia status,
            String area,
            String orientacaoId
    ) {
        Stream<IdeiaDocument> stream;
        if (principal.getPerfil() == PerfilUsuario.OPERADOR) {
            stream = ideiaRepository.findByAutorUserIdAndAtivoTrue(principal.getUserId()).stream();
        } else {
            stream = ideiaRepository.findByAtivoTrue().stream();
        }
        if (status != null) {
            stream = stream.filter(i -> i.getStatus() == status);
        }
        if (area != null && !area.isBlank()) {
            stream = stream.filter(i -> area.equalsIgnoreCase(i.getArea()));
        }
        if (orientacaoId != null && !orientacaoId.isBlank()) {
            stream = stream.filter(i -> orientacaoId.equals(i.getOrientacaoId()));
        }
        Comparator<IdeiaDocument> comparator = principal.getPerfil() == PerfilUsuario.OPERADOR
                ? Comparator.comparing(IdeiaDocument::getDataCriacao, Comparator.nullsLast(Comparator.naturalOrder())).reversed()
                : Comparator
                .comparing(IdeiaDocument::getScoreIa, Comparator.nullsLast(Comparator.reverseOrder()))
                .thenComparing(IdeiaDocument::getPrioridade, Comparator.nullsLast(Comparator.reverseOrder()))
                .thenComparing(IdeiaDocument::getDataCriacao, Comparator.nullsLast(Comparator.reverseOrder()));
        List<IdeiaDocument> docs = stream.sorted(comparator).toList();
        Map<String, String> nomes = nomesPorAutor(docs);
        return docs.stream().map(doc -> toResponse(doc, nomes)).toList();
    }

    public IdeiaResponse obter(String id, UsuarioPrincipal principal) {
        IdeiaDocument doc = requireAccessible(id, principal);
        return toResponse(doc);
    }

    public IdeiaResponse criar(IdeiaRequest request, UsuarioPrincipal principal) {
        orientacaoService.requireAtiva(request.orientacaoId());
        IdeiaDocument doc = new IdeiaDocument();
        doc.setAutorUserId(principal.getUserId());
        applyRequest(doc, request);
        doc.setStatus(StatusIdeia.PENDENTE);
        Instant now = Instant.now();
        doc.setDataCriacao(now);
        doc.setDataAtualizacao(now);
        return toResponse(ideiaRepository.save(doc));
    }

    public IdeiaResponse atualizar(String id, IdeiaRequest request, UsuarioPrincipal principal) {
        IdeiaDocument doc = requireOwned(id, principal);
        if (doc.getStatus() != StatusIdeia.PENDENTE) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Ideia não pode ser editada neste status");
        }
        orientacaoService.requireAtiva(request.orientacaoId());
        applyRequest(doc, request);
        doc.setDataAtualizacao(Instant.now());
        return toResponse(ideiaRepository.save(doc));
    }

    public void excluir(String id, UsuarioPrincipal principal) {
        IdeiaDocument doc = requireOwned(id, principal);
        if (doc.getStatus() != StatusIdeia.PENDENTE) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Somente ideias pendentes podem ser excluídas");
        }
        doc.marcarExcluido();
        ideiaRepository.save(doc);
    }

    public IdeiaResponse priorizar(String id, PrioridadeRequest request) {
        IdeiaDocument doc = requireAtiva(id);
        requireAvaliavel(doc);
        doc.setPrioridade(request.prioridade());
        doc.setDataAtualizacao(Instant.now());
        return toResponse(ideiaRepository.save(doc));
    }

    public IdeiaResponse avaliar(String id, AvaliacaoRequest request) {
        if (request.status() != StatusIdeia.APROVADA && request.status() != StatusIdeia.REPROVADA) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Status de avaliação inválido");
        }
        if (request.status() == StatusIdeia.REPROVADA
                && (request.feedback() == null || request.feedback().isBlank())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Feedback obrigatório ao reprovar");
        }
        IdeiaDocument doc = requireAtiva(id);
        requireAvaliavel(doc);
        Instant agora = Instant.now();
        doc.setStatus(request.status());
        doc.setFeedbackReprovacao(request.status() == StatusIdeia.REPROVADA ? request.feedback().trim() : null);
        doc.setDataAvaliacao(agora);
        doc.setDataAtualizacao(agora);
        return toResponse(ideiaRepository.save(doc));
    }

    public List<IdeiaDocument> findPendentesByIds(List<String> ids, String orientacaoId) {
        return ids.stream()
                .map(ideiaRepository::findByIdAndAtivoTrue)
                .filter(opt -> opt.isPresent())
                .map(opt -> opt.get())
                .filter(doc -> java.util.Objects.equals(orientacaoId, doc.getOrientacaoId()))
                .filter(doc -> doc.getStatus() == StatusIdeia.PENDENTE)
                .toList();
    }

    public void persistirScores(List<IdeaScoreItem> ranking, String modelo, boolean fallback) {
        Instant now = Instant.now();
        for (IdeaScoreItem item : ranking) {
            ideiaRepository.findByIdAndAtivoTrue(item.ideiaId()).ifPresent(doc -> {
                doc.setScoreIa(clampScore(item.score()));
                doc.setJustificativaIa(item.justificativa());
                doc.setScoreIaModelo(modelo);
                doc.setScoreIaFallback(fallback);
                doc.setDataAtualizacao(now);
                ideiaRepository.save(doc);
            });
        }
    }

    private void applyRequest(IdeiaDocument doc, IdeiaRequest request) {
        doc.setTitulo(request.titulo());
        doc.setDescricao(request.descricao());
        doc.setTipo(request.tipo());
        doc.setArea(request.area());
        doc.setOrientacaoId(request.orientacaoId());
        doc.setImpacto(request.impacto());
        doc.setEsforco(request.esforco());
    }

    private IdeiaDocument requireAtiva(String id) {
        return ideiaRepository.findByIdAndAtivoTrue(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Ideia não encontrada"));
    }

    private void requireAvaliavel(IdeiaDocument doc) {
        if (doc.getStatus() != StatusIdeia.PENDENTE) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Ideia não está pendente");
        }
    }

    static int clampScore(int score) {
        return Math.min(100, Math.max(0, score));
    }

    private IdeiaDocument requireOwned(String id, UsuarioPrincipal principal) {
        IdeiaDocument doc = ideiaRepository.findByIdAndAtivoTrue(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Ideia não encontrada"));
        if (!doc.getAutorUserId().equals(principal.getUserId())) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Ideia de outro operador");
        }
        return doc;
    }

    private IdeiaDocument requireAccessible(String id, UsuarioPrincipal principal) {
        IdeiaDocument doc = ideiaRepository.findByIdAndAtivoTrue(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Ideia não encontrada"));
        if (principal.getPerfil() == PerfilUsuario.OPERADOR
                && !doc.getAutorUserId().equals(principal.getUserId())) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Ideia de outro operador");
        }
        return doc;
    }

    private Map<String, String> nomesPorAutor(List<IdeiaDocument> docs) {
        List<String> ids = docs.stream()
                .map(IdeiaDocument::getAutorUserId)
                .filter(Objects::nonNull)
                .distinct()
                .toList();
        Map<String, String> nomes = new HashMap<>();
        usuarioRepository.findAllById(ids).forEach(usuario -> {
            if (nomeValido(usuario.getNome())) {
                nomes.put(usuario.getId(), usuario.getNome());
            }
        });
        return nomes;
    }

    private IdeiaResponse toResponse(IdeiaDocument doc) {
        String autorNome = usuarioRepository.findById(doc.getAutorUserId())
                .map(UsuarioDocument::getNome)
                .filter(IdeiaService::nomeValido)
                .orElse(doc.getAutorUserId());
        return toResponse(doc, autorNome);
    }

    private IdeiaResponse toResponse(IdeiaDocument doc, Map<String, String> nomes) {
        String autorNome = nomes.getOrDefault(doc.getAutorUserId(), doc.getAutorUserId());
        return toResponse(doc, autorNome);
    }

    private IdeiaResponse toResponse(IdeiaDocument doc, String autorNome) {
        return new IdeiaResponse(
                doc.getId(),
                doc.getAutorUserId(),
                autorNome,
                doc.getTitulo(),
                doc.getDescricao(),
                doc.getTipo(),
                doc.getArea(),
                doc.getOrientacaoId(),
                doc.getStatus(),
                doc.getPrioridade(),
                doc.getImpacto(),
                doc.getEsforco(),
                doc.getScoreIa(),
                doc.getJustificativaIa(),
                doc.getScoreIaFallback(),
                doc.getFeedbackReprovacao(),
                doc.getDataCriacao(),
                doc.getDataAtualizacao()
        );
    }

    private static boolean nomeValido(String nome) {
        return nome != null && !nome.isBlank();
    }
}
