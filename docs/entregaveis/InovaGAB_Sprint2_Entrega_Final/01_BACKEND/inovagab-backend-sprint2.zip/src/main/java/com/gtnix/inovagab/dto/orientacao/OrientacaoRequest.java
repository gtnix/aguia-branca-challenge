package com.gtnix.inovagab.dto.orientacao;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record OrientacaoRequest(
        @NotBlank @Size(max = 200) String titulo,
        @Size(max = 4000) String descricao,
        @NotBlank @Size(max = 80) String categoria,
        @NotBlank @Size(max = 120) String campanha
) {
}
