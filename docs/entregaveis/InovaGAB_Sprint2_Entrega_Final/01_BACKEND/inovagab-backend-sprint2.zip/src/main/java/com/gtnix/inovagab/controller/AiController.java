package com.gtnix.inovagab.controller;

import com.gtnix.inovagab.dto.ai.DashboardNarrativeResponse;
import com.gtnix.inovagab.dto.ai.ScoreIdeasRequest;
import com.gtnix.inovagab.dto.ai.ScoreIdeasResponse;
import com.gtnix.inovagab.service.AiScoreService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/ai")
public class AiController {

    private final AiScoreService aiScoreService;

    public AiController(AiScoreService aiScoreService) {
        this.aiScoreService = aiScoreService;
    }

    @PostMapping("/score-ideas")
    @PreAuthorize("hasRole('GESTOR')")
    public ScoreIdeasResponse scoreIdeas(@Valid @RequestBody ScoreIdeasRequest request) {
        return aiScoreService.score(request);
    }

    @GetMapping("/dashboard-narrative")
    @PreAuthorize("hasRole('LIDER')")
    public DashboardNarrativeResponse dashboardNarrative(
            @RequestParam(required = false) String orientacaoId) {
        return aiScoreService.narrativaDashboard(orientacaoId);
    }
}
