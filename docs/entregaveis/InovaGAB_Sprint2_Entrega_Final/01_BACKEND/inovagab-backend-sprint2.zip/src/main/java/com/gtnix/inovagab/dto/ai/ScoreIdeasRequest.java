package com.gtnix.inovagab.dto.ai;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import java.util.List;

public record ScoreIdeasRequest(
        @NotBlank String orientacaoId,
        @NotEmpty @Size(max = 50) List<String> ideiaIds
) {
}
