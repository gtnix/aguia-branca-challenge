package com.gtnix.inovagab.dto.ideia;

import com.gtnix.inovagab.domain.StatusIdeia;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record AvaliacaoRequest(
        @NotNull StatusIdeia status,
        @Size(max = 2000) String feedback
) {
}
