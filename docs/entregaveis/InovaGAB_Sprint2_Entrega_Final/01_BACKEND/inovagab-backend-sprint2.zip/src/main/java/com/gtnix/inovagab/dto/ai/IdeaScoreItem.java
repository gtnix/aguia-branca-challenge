package com.gtnix.inovagab.dto.ai;

public record IdeaScoreItem(
        String ideiaId,
        int score,
        String justificativa
) {
}
