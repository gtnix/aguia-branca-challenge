package com.gtnix.inovagab.config;

import com.gtnix.inovagab.document.IdeiaDocument;
import com.gtnix.inovagab.document.OrientacaoDocument;
import com.gtnix.inovagab.document.ProjetoDocument;
import com.gtnix.inovagab.document.UsuarioDocument;
import com.gtnix.inovagab.domain.PerfilUsuario;
import com.gtnix.inovagab.domain.StatusIdeia;
import com.gtnix.inovagab.repository.IdeiaRepository;
import com.gtnix.inovagab.repository.OrientacaoRepository;
import com.gtnix.inovagab.repository.ProjetoRepository;
import com.gtnix.inovagab.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Set;
import java.util.regex.Pattern;

@Component
public class DataSeeder implements CommandLineRunner {

    static final String CATEGORIA_DEMO = "EFICIENCIA_OPERACIONAL";
    static final Set<String> CATEGORIAS_LEGADAS = Set.of("Operações", "OPERACOES", "Operacoes");

    private static final Pattern CONTEUDO_TESTE = Pattern.compile(
            "(?i).*(crud|smoke|fatia|alheia|ownership|auditoria|audit).*"
    );

    static final String ID_ORI_EFICIENCIA = "ori-eficiencia";
    static final String ID_ORI_PASSAGEIRO = "ori-passageiro";
    static final String ID_ORI_SEGURANCA = "ori-seguranca";
    static final String ID_ORI_SUSTENTABILIDADE = "ori-sustentabilidade";

    static final String ID_IDEIA_TELEMETRIA = "ideia-telemetria";
    static final String ID_IDEIA_CHECKIN = "ideia-checkin";
    static final String ID_IDEIA_OFICINA = "ideia-oficina";
    static final String ID_IDEIA_ROTAS = "ideia-rotas";
    static final String ID_IDEIA_PREDITIVA = "ideia-preditiva";

    static final String ID_PROJ_PREDITIVA = "proj-preditiva";
    static final String ID_PROJ_TELEMETRIA = "proj-telemetria";

    private final UsuarioRepository usuarioRepository;
    private final OrientacaoRepository orientacaoRepository;
    private final IdeiaRepository ideiaRepository;
    private final ProjetoRepository projetoRepository;
    private final PasswordEncoder passwordEncoder;

    public DataSeeder(
            UsuarioRepository usuarioRepository,
            OrientacaoRepository orientacaoRepository,
            IdeiaRepository ideiaRepository,
            ProjetoRepository projetoRepository,
            PasswordEncoder passwordEncoder
    ) {
        this.usuarioRepository = usuarioRepository;
        this.orientacaoRepository = orientacaoRepository;
        this.ideiaRepository = ideiaRepository;
        this.projetoRepository = projetoRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (usuarioRepository.count() == 0) {
            seedDemo();
        }
        normalizarCategoriasLegadas();
        removerConteudoTeste();
        upsertCatalogoSetorial();
    }

    private void seedDemo() {
        String hash = passwordEncoder.encode("123456");
        usuarioRepository.save(usuario("user-lider", "Marcos Silva",
                "marcos.silva@aguiabranca.com.br", hash, PerfilUsuario.LIDER));
        usuarioRepository.save(usuario("user-gestor", "Ana Oliveira",
                "ana.oliveira@aguiabranca.com.br", hash, PerfilUsuario.GESTOR));
        usuarioRepository.save(usuario("user-operador", "Pedro Santos",
                "pedro.santos@aguiabranca.com.br", hash, PerfilUsuario.OPERADOR));
    }

    void normalizarCategoriasLegadas() {
        for (OrientacaoDocument doc : orientacaoRepository.findAll()) {
            if (doc.getCategoria() != null && CATEGORIAS_LEGADAS.contains(doc.getCategoria())) {
                doc.setCategoria(CATEGORIA_DEMO);
                orientacaoRepository.save(doc);
            }
        }
    }

    void removerConteudoTeste() {
        for (IdeiaDocument doc : ideiaRepository.findAll()) {
            if (doc.isAtivo() && isConteudoTeste(doc.getTitulo(), doc.getDescricao())) {
                doc.marcarExcluido();
                ideiaRepository.save(doc);
            }
        }
        for (ProjetoDocument doc : projetoRepository.findAll()) {
            if (doc.isAtivo() && isConteudoTeste(doc.getTitulo(), doc.getDescricao(), doc.getObjetivo())) {
                doc.marcarExcluido();
                projetoRepository.save(doc);
            }
        }
        for (OrientacaoDocument doc : orientacaoRepository.findAll()) {
            if (doc.isAtivo() && isConteudoTeste(doc.getTitulo(), doc.getDescricao())) {
                doc.marcarExcluido();
                orientacaoRepository.save(doc);
            }
        }
    }

    void upsertCatalogoSetorial() {
        Instant now = Instant.now();
        String campanha = "Águia 2026 — Inovação em Campo";

        salvarOrientacao(
                ID_ORI_EFICIENCIA,
                "Eficiência operacional e experiência do passageiro",
                "Priorizar iniciativas que reduzam custos logísticos e melhorem NPS nas linhas rodoviárias.",
                CATEGORIA_DEMO,
                campanha,
                now
        );
        salvarOrientacao(
                ID_ORI_PASSAGEIRO,
                "Experiência digital do passageiro",
                "Modernizar embarque, bilhetagem e comunicação com o passageiro nos terminais e no app.",
                "EXPERIENCIA_CLIENTE",
                campanha,
                now
        );
        salvarOrientacao(
                ID_ORI_SEGURANCA,
                "Segurança operacional e jornada segura",
                "Reduzir incidentes com treinamento, telemetria de condução e checklists digitais na frota.",
                "SEGURANCA",
                campanha,
                now
        );
        salvarOrientacao(
                ID_ORI_SUSTENTABILIDADE,
                "Redução de emissões da frota",
                "Monitorar consumo de combustível e rotas para diminuir emissões de CO₂ até 2027.",
                "SUSTENTABILIDADE",
                campanha,
                now
        );

        salvarIdeia(
                ID_IDEIA_TELEMETRIA,
                ID_ORI_EFICIENCIA,
                "Rastreamento de frota em tempo real",
                "Usar telemetria para reduzir combustível e melhorar pontualidade das linhas.",
                StatusIdeia.PENDENTE,
                4,
                3,
                now
        );
        salvarIdeia(
                ID_IDEIA_CHECKIN,
                ID_ORI_PASSAGEIRO,
                "Check-in digital no embarque",
                "QR Code no app reduz filas e agiliza a conferência de passageiros nos terminais.",
                StatusIdeia.PENDENTE,
                5,
                2,
                now
        );
        salvarIdeia(
                ID_IDEIA_OFICINA,
                ID_ORI_EFICIENCIA,
                "Oficina sem papel",
                "Ordens de serviço digitais na manutenção da frota, com histórico por veículo.",
                StatusIdeia.PENDENTE,
                3,
                4,
                now
        );
        IdeiaDocument rotas = salvarIdeia(
                ID_IDEIA_ROTAS,
                ID_ORI_SUSTENTABILIDADE,
                "Roteirização sustentável da última milha",
                "Algoritmo de rotas reduz km ocioso e emissões na operação logística.",
                StatusIdeia.PENDENTE,
                4,
                3,
                now
        );
        rotas.setArea("LOGISTICA");
        ideiaRepository.save(rotas);

        IdeiaDocument preditiva = salvarIdeia(
                ID_IDEIA_PREDITIVA,
                ID_ORI_EFICIENCIA,
                "Manutenção preditiva da frota",
                "Sensores IoT antecipam falhas e reduzem tempo parado na oficina.",
                StatusIdeia.CONVERTIDA_PROJETO,
                5,
                3,
                now.minus(Duration.ofDays(10))
        );
        preditiva.setDataAvaliacao(now.minus(Duration.ofDays(3)));
        preditiva.setDataAtualizacao(now.minus(Duration.ofDays(3)));
        ideiaRepository.save(preditiva);

        salvarProjeto(
                ID_PROJ_PREDITIVA,
                ID_ORI_EFICIENCIA,
                ID_IDEIA_PREDITIVA,
                "Manutenção preditiva da frota",
                "Reduzir tempo parado da frota com sensores IoT.",
                preditiva.getDescricao(),
                "EM_ANDAMENTO",
                "PLANEJADO",
                BigDecimal.valueOf(80_000),
                BigDecimal.valueOf(9_000),
                now
        );
        salvarProjeto(
                ID_PROJ_TELEMETRIA,
                ID_ORI_EFICIENCIA,
                null,
                "Telemetria da frota",
                "Painel de desempenho operacional em tempo real para gestores de linha.",
                "Dashboard de telemetria integrado à central de operações da Águia Branca.",
                "EM_ANDAMENTO",
                "EM_ANDAMENTO",
                BigDecimal.valueOf(60_000),
                BigDecimal.valueOf(5_500),
                now
        );
    }

    private OrientacaoDocument salvarOrientacao(
            String id,
            String titulo,
            String descricao,
            String categoria,
            String campanha,
            Instant now
    ) {
        OrientacaoDocument doc = orientacaoRepository.findById(id).orElseGet(OrientacaoDocument::new);
        doc.setId(id);
        doc.setTitulo(titulo);
        doc.setDescricao(descricao);
        doc.setCategoria(categoria);
        doc.setCampanha(campanha);
        doc.setAtivo(true);
        doc.setDeletedAt(null);
        if (doc.getDataCriacao() == null) {
            doc.setDataCriacao(now);
        }
        doc.setDataAtualizacao(now);
        if (doc.getCriadoPorUserId() == null) {
            doc.setCriadoPorUserId("user-lider");
        }
        return orientacaoRepository.save(doc);
    }

    private IdeiaDocument salvarIdeia(
            String id,
            String orientacaoId,
            String titulo,
            String descricao,
            StatusIdeia status,
            int impacto,
            int esforco,
            Instant dataCriacao
    ) {
        IdeiaDocument doc = ideiaRepository.findById(id).orElseGet(IdeiaDocument::new);
        doc.setId(id);
        doc.setAutorUserId("user-operador");
        doc.setTitulo(titulo);
        doc.setDescricao(descricao);
        doc.setTipo("IDEIA");
        if (doc.getArea() == null) {
            doc.setArea("OPERACOES");
        }
        doc.setOrientacaoId(orientacaoId);
        doc.setStatus(status);
        doc.setImpacto(impacto);
        doc.setEsforco(esforco);
        doc.setAtivo(true);
        doc.setDeletedAt(null);
        doc.setDataCriacao(dataCriacao);
        if (doc.getDataAtualizacao() == null) {
            doc.setDataAtualizacao(dataCriacao);
        }
        return ideiaRepository.save(doc);
    }

    private void salvarProjeto(
            String id,
            String orientacaoId,
            String ideiaId,
            String titulo,
            String objetivo,
            String descricao,
            String status,
            String etapa,
            BigDecimal investimento,
            BigDecimal retorno,
            Instant now
    ) {
        ProjetoDocument doc = projetoRepository.findById(id).orElseGet(ProjetoDocument::new);
        doc.setId(id);
        doc.setTitulo(titulo);
        doc.setObjetivo(objetivo);
        doc.setDescricao(descricao);
        doc.setArea("OPERACOES");
        doc.setOrientacaoId(orientacaoId);
        doc.setIdeiaId(ideiaId);
        doc.setEtapa(etapa);
        doc.setStatus(status);
        doc.setInvestimento(investimento);
        doc.setRetorno(retorno);
        doc.setPrazo(LocalDate.now().plusMonths(6));
        doc.setProgressoPercentual(status.equals("EM_ANDAMENTO") ? 35 : 0);
        doc.setResponsavelUserId("user-gestor");
        doc.setAtivo(true);
        doc.setDeletedAt(null);
        if (doc.getDataCriacao() == null) {
            doc.setDataCriacao(now);
        }
        doc.setDataAtualizacao(now);
        projetoRepository.save(doc);
    }

    static boolean isConteudoTeste(String... textos) {
        for (String texto : textos) {
            if (texto != null && CONTEUDO_TESTE.matcher(texto).matches()) {
                return true;
            }
        }
        return false;
    }

    private UsuarioDocument usuario(
            String id,
            String nome,
            String email,
            String hash,
            PerfilUsuario perfil
    ) {
        UsuarioDocument u = new UsuarioDocument();
        u.setId(id);
        u.setNome(nome);
        u.setEmail(email);
        u.setSenhaHash(hash);
        u.setPerfil(perfil);
        u.setArea("OPERACOES");
        u.setDivisao("LOGISTICA");
        return u;
    }
}
