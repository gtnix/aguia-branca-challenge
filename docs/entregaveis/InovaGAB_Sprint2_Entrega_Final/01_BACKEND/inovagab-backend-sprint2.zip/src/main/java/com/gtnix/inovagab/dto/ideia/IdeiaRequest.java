package com.gtnix.inovagab.dto.ideia;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record IdeiaRequest(
        @NotBlank @Size(max = 200) String titulo,
        @NotBlank @Size(max = 4000) String descricao,
        @Size(max = 40) String tipo,
        @Size(max = 40) String area,
        @NotBlank String orientacaoId,
        @Min(1) @Max(5) Integer impacto,
        @Min(1) @Max(5) Integer esforco
) {
}
