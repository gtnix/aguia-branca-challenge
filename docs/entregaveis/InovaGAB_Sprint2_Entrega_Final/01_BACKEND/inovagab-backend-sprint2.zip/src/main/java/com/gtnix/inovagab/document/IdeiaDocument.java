package com.gtnix.inovagab.document;

import com.gtnix.inovagab.domain.StatusIdeia;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Document(collection = "ideias")
@CompoundIndexes({
        @CompoundIndex(name = "idx_ideias_autor_ativo", def = "{'autorUserId': 1, 'ativo': 1}"),
        @CompoundIndex(name = "idx_ideias_status_ativo", def = "{'status': 1, 'ativo': 1}"),
        @CompoundIndex(name = "idx_ideias_area_ativo", def = "{'area': 1, 'ativo': 1}"),
        @CompoundIndex(name = "idx_ideias_orientacao_status_ativo", def = "{'orientacaoId': 1, 'status': 1, 'ativo': 1}")
})
public class IdeiaDocument extends SoftDeletableDocument {

    @Id
    private String id;
    private String autorUserId;
    private String titulo;
    private String descricao;
    private String tipo;
    private String area;
    private String orientacaoId;
    private StatusIdeia status;
    private Integer prioridade;
    private Integer impacto;
    private Integer esforco;
    private Integer scoreIa;
    private String justificativaIa;
    private String scoreIaModelo;
    private Boolean scoreIaFallback;
    private String feedbackReprovacao;
    private Instant dataAvaliacao;
    private Instant dataCriacao;
    private Instant dataAtualizacao;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAutorUserId() {
        return autorUserId;
    }

    public void setAutorUserId(String autorUserId) {
        this.autorUserId = autorUserId;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getOrientacaoId() {
        return orientacaoId;
    }

    public void setOrientacaoId(String orientacaoId) {
        this.orientacaoId = orientacaoId;
    }

    public StatusIdeia getStatus() {
        return status;
    }

    public void setStatus(StatusIdeia status) {
        this.status = status;
    }

    public Integer getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(Integer prioridade) {
        this.prioridade = prioridade;
    }

    public Integer getImpacto() {
        return impacto;
    }

    public void setImpacto(Integer impacto) {
        this.impacto = impacto;
    }

    public Integer getEsforco() {
        return esforco;
    }

    public void setEsforco(Integer esforco) {
        this.esforco = esforco;
    }

    public Integer getScoreIa() {
        return scoreIa;
    }

    public void setScoreIa(Integer scoreIa) {
        this.scoreIa = scoreIa;
    }

    public String getJustificativaIa() {
        return justificativaIa;
    }

    public void setJustificativaIa(String justificativaIa) {
        this.justificativaIa = justificativaIa;
    }

    public String getScoreIaModelo() {
        return scoreIaModelo;
    }

    public void setScoreIaModelo(String scoreIaModelo) {
        this.scoreIaModelo = scoreIaModelo;
    }

    public Boolean getScoreIaFallback() {
        return scoreIaFallback;
    }

    public void setScoreIaFallback(Boolean scoreIaFallback) {
        this.scoreIaFallback = scoreIaFallback;
    }

    public String getFeedbackReprovacao() {
        return feedbackReprovacao;
    }

    public void setFeedbackReprovacao(String feedbackReprovacao) {
        this.feedbackReprovacao = feedbackReprovacao;
    }

    public Instant getDataAvaliacao() {
        return dataAvaliacao;
    }

    public void setDataAvaliacao(Instant dataAvaliacao) {
        this.dataAvaliacao = dataAvaliacao;
    }

    public Instant getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(Instant dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public Instant getDataAtualizacao() {
        return dataAtualizacao;
    }

    public void setDataAtualizacao(Instant dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }
}
