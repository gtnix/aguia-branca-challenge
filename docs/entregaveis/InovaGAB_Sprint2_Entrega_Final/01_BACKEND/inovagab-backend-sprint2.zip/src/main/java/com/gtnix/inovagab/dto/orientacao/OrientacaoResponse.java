package com.gtnix.inovagab.dto.orientacao;

import java.time.Instant;

public record OrientacaoResponse(
        String id,
        String titulo,
        String descricao,
        String categoria,
        String campanha,
        Instant dataCriacao,
        Instant dataAtualizacao,
        boolean ativo,
        String criadoPorUserId
) {
}
