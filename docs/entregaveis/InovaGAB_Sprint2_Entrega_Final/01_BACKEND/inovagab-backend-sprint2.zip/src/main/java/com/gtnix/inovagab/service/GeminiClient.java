package com.gtnix.inovagab.service;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.List;
import java.util.Map;

@Component
public class GeminiClient {

    static final String GENERATE_URL_PREFIX = "https://generativelanguage.googleapis.com/v1beta/models/";
    static final String API_KEY_HEADER = "x-goog-api-key";

    private final RestClient restClient;

    public GeminiClient() {
        this(RestClient.builder().build());
    }

    GeminiClient(RestClient restClient) {
        this.restClient = restClient;
    }

    public String generateContent(String model, String apiKey, String prompt) {
        String url = GENERATE_URL_PREFIX + model + ":generateContent";
        Map<String, Object> body = Map.of(
                "contents", List.of(Map.of(
                        "parts", List.of(Map.of("text", prompt))
                ))
        );
        return restClient.post()
                .uri(url)
                .contentType(MediaType.APPLICATION_JSON)
                .header(API_KEY_HEADER, apiKey)
                .body(body)
                .retrieve()
                .body(String.class);
    }
}
