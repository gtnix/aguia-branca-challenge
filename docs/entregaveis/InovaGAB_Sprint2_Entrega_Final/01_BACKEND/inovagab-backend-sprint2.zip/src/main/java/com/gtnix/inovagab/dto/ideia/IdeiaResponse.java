package com.gtnix.inovagab.dto.ideia;

import com.gtnix.inovagab.domain.StatusIdeia;

import java.time.Instant;

public record IdeiaResponse(
        String id,
        String autorUserId,
        String autorNome,
        String titulo,
        String descricao,
        String tipo,
        String area,
        String orientacaoId,
        StatusIdeia status,
        Integer prioridade,
        Integer impacto,
        Integer esforco,
        Integer scoreIa,
        String justificativaIa,
        Boolean scoreIaFallback,
        String feedbackReprovacao,
        Instant dataCriacao,
        Instant dataAtualizacao
) {
}
