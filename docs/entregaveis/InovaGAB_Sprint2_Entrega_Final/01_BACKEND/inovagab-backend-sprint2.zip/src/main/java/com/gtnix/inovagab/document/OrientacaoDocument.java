package com.gtnix.inovagab.document;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Document(collection = "orientacoes")
@CompoundIndex(name = "idx_orientacoes_categoria_ativo", def = "{'categoria': 1, 'ativo': 1}")
public class OrientacaoDocument extends SoftDeletableDocument {

    @Id
    private String id;
    private String titulo;
    private String descricao;
    @Indexed
    private String categoria;
    private String campanha;
    private Instant dataCriacao;
    private Instant dataAtualizacao;
    private String criadoPorUserId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getCampanha() {
        return campanha;
    }

    public void setCampanha(String campanha) {
        this.campanha = campanha;
    }

    public Instant getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(Instant dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public Instant getDataAtualizacao() {
        return dataAtualizacao;
    }

    public void setDataAtualizacao(Instant dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }

    public String getCriadoPorUserId() {
        return criadoPorUserId;
    }

    public void setCriadoPorUserId(String criadoPorUserId) {
        this.criadoPorUserId = criadoPorUserId;
    }
}
