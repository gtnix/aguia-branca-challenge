package com.gtnix.inovagab.service;

import com.gtnix.inovagab.document.OrientacaoDocument;
import com.gtnix.inovagab.domain.PerfilUsuario;
import com.gtnix.inovagab.dto.orientacao.OrientacaoRequest;
import com.gtnix.inovagab.dto.orientacao.OrientacaoResponse;
import com.gtnix.inovagab.repository.OrientacaoRepository;
import com.gtnix.inovagab.security.UsuarioPrincipal;
import com.gtnix.inovagab.web.ApiException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

@Service
public class OrientacaoService {

    private final OrientacaoRepository orientacaoRepository;

    public OrientacaoService(OrientacaoRepository orientacaoRepository) {
        this.orientacaoRepository = orientacaoRepository;
    }

    public List<OrientacaoResponse> listar(boolean apenasAtivas) {
        List<OrientacaoDocument> docs = apenasAtivas
                ? orientacaoRepository.findByAtivoTrue()
                : orientacaoRepository.findAll();
        return docs.stream().map(this::toResponse).toList();
    }

    public OrientacaoResponse obter(String id, UsuarioPrincipal principal) {
        OrientacaoDocument doc = orientacaoRepository.findById(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Orientação não encontrada"));
        if (!doc.isAtivo() && principal.getPerfil() != PerfilUsuario.LIDER) {
            throw new ApiException(HttpStatus.NOT_FOUND, "Orientação não encontrada");
        }
        return toResponse(doc);
    }

    public OrientacaoResponse criar(OrientacaoRequest request, UsuarioPrincipal principal) {
        OrientacaoDocument doc = new OrientacaoDocument();
        doc.setTitulo(request.titulo());
        doc.setDescricao(request.descricao());
        doc.setCategoria(request.categoria());
        doc.setCampanha(request.campanha());
        doc.setCriadoPorUserId(principal.getUserId());
        Instant now = Instant.now();
        doc.setDataCriacao(now);
        doc.setDataAtualizacao(now);
        return toResponse(orientacaoRepository.save(doc));
    }

    public OrientacaoResponse atualizar(String id, OrientacaoRequest request) {
        OrientacaoDocument doc = orientacaoRepository.findByIdAndAtivoTrue(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Orientação não encontrada"));
        doc.setTitulo(request.titulo());
        doc.setDescricao(request.descricao());
        doc.setCategoria(request.categoria());
        doc.setCampanha(request.campanha());
        doc.setDataAtualizacao(Instant.now());
        return toResponse(orientacaoRepository.save(doc));
    }

    public OrientacaoResponse definirAtivo(String id, boolean ativo) {
        OrientacaoDocument doc = orientacaoRepository.findById(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Orientação não encontrada"));
        if (ativo) {
            doc.setAtivo(true);
            doc.setDeletedAt(null);
        } else {
            doc.setAtivo(false);
        }
        doc.setDataAtualizacao(Instant.now());
        return toResponse(orientacaoRepository.save(doc));
    }

    public void excluir(String id) {
        OrientacaoDocument doc = orientacaoRepository.findById(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Orientação não encontrada"));
        if (doc.getDeletedAt() != null) {
            return;
        }
        doc.marcarExcluido();
        doc.setDataAtualizacao(Instant.now());
        orientacaoRepository.save(doc);
    }

    public OrientacaoDocument requireAtiva(String orientacaoId) {
        return orientacaoRepository.findByIdAndAtivoTrue(orientacaoId)
                .orElseThrow(() -> new ApiException(HttpStatus.BAD_REQUEST, "Orientação estratégica inválida ou inativa"));
    }

    private OrientacaoResponse toResponse(OrientacaoDocument doc) {
        return new OrientacaoResponse(
                doc.getId(),
                doc.getTitulo(),
                doc.getDescricao(),
                doc.getCategoria(),
                doc.getCampanha(),
                doc.getDataCriacao(),
                doc.getDataAtualizacao(),
                doc.isAtivo(),
                doc.getCriadoPorUserId()
        );
    }
}
