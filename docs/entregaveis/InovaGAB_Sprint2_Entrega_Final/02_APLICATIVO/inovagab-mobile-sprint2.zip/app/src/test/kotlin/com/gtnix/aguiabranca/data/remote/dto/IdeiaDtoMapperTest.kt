package com.gtnix.aguiabranca.data.remote.dto

import com.gtnix.aguiabranca.domain.model.AreaAtuacao
import com.gtnix.aguiabranca.domain.model.StatusIdeia
import com.gtnix.aguiabranca.domain.model.TipoIdeia
import org.junit.Assert.assertEquals
import org.junit.Test

class IdeiaDtoMapperTest {

    @Test
    fun `mapeia contrato da API para dominio`() {
        val dto = IdeiaDto(
            id = "ideia-1",
            autorUserId = "user-operador",
            titulo = "Rastreamento",
            descricao = "Telemetria da frota",
            tipo = "PROBLEMA",
            area = "LOGISTICA",
            orientacaoId = "ori-1",
            status = "PENDENTE",
            impacto = 4,
            esforco = 2,
            scoreIa = 87,
            justificativaIa = "Alto alinhamento",
            scoreIaFallback = false,
            dataCriacao = "2026-01-15T10:00:00Z"
        )

        val domain = dto.toDomain()

        assertEquals("ideia-1", domain.id)
        assertEquals("user-operador", domain.autorId)
        assertEquals("user-operador", domain.autorNome)
        assertEquals(TipoIdeia.PROBLEMA, domain.tipo)
        assertEquals(AreaAtuacao.LOGISTICA, domain.area)
        assertEquals("ori-1", domain.orientacaoId)
        assertEquals(StatusIdeia.PENDENTE, domain.status)
        assertEquals(4, domain.impactoEstimado)
        assertEquals(87, domain.scoreIa)
        assertEquals("Alto alinhamento", domain.justificativaIa)
    }

    @Test
    fun `autorNome da API prevalece sobre o id`() {
        val dto = IdeiaDto(
            id = "ideia-1",
            autorUserId = "user-operador",
            autorNome = "Pedro Santos",
            titulo = "Rastreamento",
            status = "PENDENTE",
            orientacaoId = "ori-1"
        )

        assertEquals("Pedro Santos", dto.toDomain().autorNome)
    }

    @Test
    fun `status desconhecido cai em PENDENTE`() {
        val dto = IdeiaDto(
            id = "ideia-1",
            titulo = "X",
            status = "STATUS_INEXISTENTE",
            orientacaoId = "ori-1"
        )

        assertEquals(StatusIdeia.PENDENTE, dto.toDomain().status)
    }
}
