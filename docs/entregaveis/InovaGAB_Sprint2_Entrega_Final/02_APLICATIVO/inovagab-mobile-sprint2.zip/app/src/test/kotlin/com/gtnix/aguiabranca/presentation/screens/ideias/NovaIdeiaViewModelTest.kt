package com.gtnix.aguiabranca.presentation.screens.ideias

import android.content.Context
import android.content.Intent
import android.speech.SpeechRecognizer
import android.util.Log
import com.gtnix.aguiabranca.R
import com.gtnix.aguiabranca.domain.model.AreaAtuacao
import com.gtnix.aguiabranca.domain.model.PerfilUsuario
import com.gtnix.aguiabranca.domain.model.TipoIdeia
import com.gtnix.aguiabranca.fake.FakeIdeiaRepository
import com.gtnix.aguiabranca.fake.FakeOrientacaoRepository
import com.gtnix.aguiabranca.fake.FakeSessionManager
import com.gtnix.aguiabranca.fake.TestDataFactory
import com.gtnix.aguiabranca.util.MainDispatcherRule
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkConstructor
import io.mockk.mockkStatic
import io.mockk.unmockkConstructor
import io.mockk.unmockkStatic
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class NovaIdeiaViewModelTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    private lateinit var viewModel: NovaIdeiaViewModel
    private lateinit var ideiaRepository: FakeIdeiaRepository
    private lateinit var orientacaoRepository: FakeOrientacaoRepository
    private lateinit var sessionManager: FakeSessionManager
    private val context = mockk<Context>(relaxed = true)

    @Before
    fun setup() {
        mockkStatic(Log::class)
        every { Log.w(any(), any<String>()) } returns 0
        every { Log.e(any(), any<String>(), any()) } returns 0
        mockkStatic(SpeechRecognizer::class)
        every { SpeechRecognizer.isRecognitionAvailable(any()) } returns true
        every { SpeechRecognizer.createSpeechRecognizer(any()) } returns mockk(relaxed = true)
        mockkConstructor(Intent::class)
        every { anyConstructed<Intent>().putExtra(any<String>(), any<String>()) } answers { self as Intent }
        every { anyConstructed<Intent>().putExtra(any<String>(), any<Boolean>()) } answers { self as Intent }
        every { anyConstructed<Intent>().putExtra(any<String>(), any<Int>()) } answers { self as Intent }
        ideiaRepository = FakeIdeiaRepository()
        orientacaoRepository = FakeOrientacaoRepository()
        sessionManager = FakeSessionManager()
        viewModel = NovaIdeiaViewModel(context, ideiaRepository, orientacaoRepository, sessionManager)
    }

    @After
    fun tearDown() {
        unmockkStatic(SpeechRecognizer::class)
        unmockkStatic(Log::class)
        unmockkConstructor(Intent::class)
    }

    @Test
    fun `dado campos vazios quando salva então exibe erro de validação`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        val usuario = TestDataFactory.createUsuario()
        sessionManager.setUser(usuario)

        var chamouSuccess = false
        viewModel.salvar { chamouSuccess = true }
        advanceUntilIdle()

        assertEquals(R.string.error_nova_ideia_fields, viewModel.uiState.value.errorMessageRes)
        assertTrue(!chamouSuccess)
    }

    @Test
    fun `dado usuario não logado quando salva então exibe erro`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        sessionManager.setUser(null)

        viewModel.onTituloChange("Título")
        viewModel.onDescricaoChange("Descrição")

        var chamouSuccess = false
        viewModel.salvar { chamouSuccess = true }
        advanceUntilIdle()

        assertEquals(R.string.error_user_not_logged, viewModel.uiState.value.errorMessageRes)
        assertTrue(!chamouSuccess)
    }

    @Test
    fun `dado dados válidos quando salva então chama onSuccess`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        val usuario = TestDataFactory.createUsuario()
        sessionManager.setUser(usuario)

        viewModel.onTituloChange("Nova Ideia ESG")
        viewModel.onDescricaoChange("Descrição completa da ideia")
        viewModel.onOrientacaoChange("orientacao-1")

        var chamouSuccess = false
        viewModel.salvar { chamouSuccess = true }
        advanceUntilIdle()

        assertTrue(chamouSuccess)
        assertNull(viewModel.uiState.value.errorMessageRes)
    }

    @Test
    fun `dado alteração de título quando digita então atualiza state e limpa erro`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        advanceUntilIdle()

        viewModel.onTituloChange("Novo título")
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertEquals("Novo título", state.titulo)
        assertNull(state.errorMessageRes)
    }

    @Test
    fun `dado alteração de area quando seleciona então atualiza state`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        advanceUntilIdle()

        viewModel.onAreaChange(AreaAtuacao.LOGISTICA)
        advanceUntilIdle()

        assertEquals(AreaAtuacao.LOGISTICA, viewModel.uiState.value.area)
    }

    @Test
    fun `dado alteração de tipo quando seleciona então atualiza state`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        advanceUntilIdle()

        viewModel.onTipoChange(TipoIdeia.PROBLEMA)
        advanceUntilIdle()

        assertEquals(TipoIdeia.PROBLEMA, viewModel.uiState.value.tipo)
    }

    @Test
    fun `dado orientação selecionada quando altera então atualiza state`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        advanceUntilIdle()

        viewModel.onOrientacaoChange("orientacao-1")
        advanceUntilIdle()

        assertEquals("orientacao-1", viewModel.uiState.value.orientacaoId)
    }

    @Test
    fun `dado dados sem orientacao quando salva então exibe erro`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        sessionManager.setUser(TestDataFactory.createUsuario())
        viewModel.onTituloChange("Título")
        viewModel.onDescricaoChange("Descrição")

        var chamouSuccess = false
        viewModel.salvar { chamouSuccess = true }
        advanceUntilIdle()

        assertEquals(R.string.error_ideia_orientacao_required, viewModel.uiState.value.errorMessageRes)
        assertTrue(!chamouSuccess)
    }

    @Test
    fun `dado gestor quando salva então bloqueia cadastro`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        sessionManager.setUser(TestDataFactory.createUsuario(perfil = PerfilUsuario.GESTOR))
        viewModel.onTituloChange("Título")
        viewModel.onDescricaoChange("Descrição")
        viewModel.onOrientacaoChange("orientacao-1")

        viewModel.salvar { }
        advanceUntilIdle()

        assertEquals(R.string.error_only_operator_create_ideia, viewModel.uiState.value.errorMessageRes)
    }

    @Test
    fun `dado dados válidos quando salva então ideia é persistida no repositorio`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        val usuario = TestDataFactory.createUsuario(id = "user-test")
        sessionManager.setUser(usuario)

        viewModel.onTituloChange("Ideia Persistida")
        viewModel.onDescricaoChange("Descrição da ideia persistida")
        viewModel.onAreaChange(AreaAtuacao.TI)
        viewModel.onOrientacaoChange("orientacao-1")

        viewModel.salvar { }
        advanceUntilIdle()

        assertTrue(viewModel.uiState.value.errorMessageRes == null)
    }

    @Test
    fun `dado permissão negada quando callback então para gravação e exibe erro`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        advanceUntilIdle()

        viewModel.onMicrophonePermissionDenied()
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isRecording)
        assertEquals(R.string.error_speech_permission_denied, state.errorMessageRes)
        assertTrue(state.transcribedText.isBlank())
    }

    @Test
    fun `dado reconhecimento indisponível quando inicia gravação então não simula texto demo`() = runTest {
        every { SpeechRecognizer.isRecognitionAvailable(any()) } returns false
        viewModel = NovaIdeiaViewModel(context, ideiaRepository, orientacaoRepository, sessionManager)
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        advanceUntilIdle()

        viewModel.toggleRecording()
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isRecording)
        assertEquals(R.string.error_speech_not_available, state.errorMessageRes)
        assertTrue(state.transcribedText.isBlank())
        assertFalse(state.transcribedText.contains("GPS"))
        assertFalse(state.transcribedText.contains("painéis solares"))
        assertFalse(state.transcribedText.contains("QR"))
    }

    @Test
    fun `dado erro no match sem texto quando notifica então exibe erro e não grava`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        advanceUntilIdle()

        viewModel.notifySpeechError(SpeechRecognizer.ERROR_NO_MATCH)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isRecording)
        assertEquals(R.string.error_speech_no_match, state.errorMessageRes)
        assertTrue(state.transcribedText.isBlank())
    }

    @Test
    fun `dado erro no match com texto parcial quando notifica então aplica só texto real`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        advanceUntilIdle()

        val partial = "Minha ideia real falada pelo usuário"
        viewModel.onTranscribedTextChange(partial)
        viewModel.notifySpeechError(SpeechRecognizer.ERROR_NO_MATCH)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isRecording)
        assertNull(state.errorMessageRes)
        assertEquals(partial, state.descricao)
        assertEquals(partial.take(60), state.titulo)
    }

    @Test
    fun `dado erro de cliente sem texto quando notifica então exibe erro genérico sem demo`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        advanceUntilIdle()

        viewModel.notifySpeechError(SpeechRecognizer.ERROR_CLIENT)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isRecording)
        assertEquals(R.string.error_speech_generic, state.errorMessageRes)
        assertTrue(state.transcribedText.isBlank())
    }

    @Test
    fun `dado parar gravação com transcrição vazia quando para então não inventa conteúdo`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        advanceUntilIdle()

        viewModel.toggleRecording()
        advanceUntilIdle()
        viewModel.toggleRecording()
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isRecording)
        assertTrue(state.titulo.isBlank())
        assertTrue(state.descricao.isBlank())
        assertTrue(state.transcribedText.isBlank())
    }

    @Test
    fun `dado parar gravação com texto real quando para então aplica no formulário`() = runTest {
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.uiState.collect { }
        }
        advanceUntilIdle()

        viewModel.toggleRecording()
        val spoken = "Ideia falada de verdade"
        viewModel.onTranscribedTextChange(spoken)
        viewModel.toggleRecording()
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isRecording)
        assertEquals(spoken, state.descricao)
        assertEquals(spoken, state.titulo)
    }
}

