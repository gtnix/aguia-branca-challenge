package com.gtnix.aguiabranca.presentation.components

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.gtnix.aguiabranca.R
import com.gtnix.aguiabranca.presentation.theme.InovagabTheme

@Composable
fun StatsGridLider(
    orientacoesAtivas: Int,
    ideiasAlinhadas: Int,
    projetosDirecionados: Int,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PerfilIndicatorCard(
            label = stringResource(R.string.perfil_lider_stat_orientacoes_card),
            value = orientacoesAtivas.toString(),
            icon = Icons.Default.Flag,
            iconAccent = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f)
        )

        PerfilIndicatorCard(
            label = stringResource(R.string.perfil_lider_stat_ideias_card),
            value = ideiasAlinhadas.toString(),
            icon = Icons.Default.Insights,
            iconAccent = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.weight(1f)
        )

        PerfilIndicatorCard(
            label = stringResource(R.string.perfil_lider_stat_projetos_card),
            value = projetosDirecionados.toString(),
            icon = Icons.Default.Folder,
            iconAccent = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.weight(1f)
        )
    }
}

@Preview(name = "Light")
@Preview(name = "Dark", uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun StatsGridLiderPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            StatsGridLider(
                orientacoesAtivas = 3,
                ideiasAlinhadas = 8,
                projetosDirecionados = 2,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}
