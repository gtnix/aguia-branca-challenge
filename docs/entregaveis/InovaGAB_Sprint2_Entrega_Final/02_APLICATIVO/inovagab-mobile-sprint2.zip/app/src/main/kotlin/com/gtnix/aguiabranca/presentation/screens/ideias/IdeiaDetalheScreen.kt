package com.gtnix.aguiabranca.presentation.screens.ideias

import android.content.res.Configuration
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gtnix.aguiabranca.R
import com.gtnix.aguiabranca.domain.model.AreaAtuacao
import com.gtnix.aguiabranca.domain.model.CategoriaOrientacao
import com.gtnix.aguiabranca.domain.model.Ideia
import com.gtnix.aguiabranca.domain.model.OrientacaoEstrategica
import com.gtnix.aguiabranca.domain.model.PerfilUsuario
import com.gtnix.aguiabranca.domain.model.StatusIdeia
import com.gtnix.aguiabranca.domain.model.TipoIdeia
import com.gtnix.aguiabranca.presentation.components.AguiaTopBar
import com.gtnix.aguiabranca.presentation.components.CelebrationOverlay
import com.gtnix.aguiabranca.presentation.components.InovagabButton
import com.gtnix.aguiabranca.presentation.components.InovagabButtonVariant
import com.gtnix.aguiabranca.presentation.components.ideiaStatusColor
import com.gtnix.aguiabranca.presentation.theme.InovagabTheme
import com.gtnix.aguiabranca.presentation.theme.SuccessGreen
import com.gtnix.aguiabranca.presentation.util.formatLongDate
import com.gtnix.aguiabranca.presentation.util.labelRes
import com.gtnix.aguiabranca.presentation.util.subtleBounceClick

@Composable
fun IdeiaDetalheScreen(
    viewModel: IdeiaDetalheViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToNovoProjeto: (String) -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    IdeiaDetalheScreenContent(
        uiState = uiState,
        onNavigateBack = onNavigateBack,
        onIniciarAnalise = viewModel::iniciarAnalise,
        onImpactoChange = viewModel::onImpactoChange,
        onEsforcoChange = viewModel::onEsforcoChange,
        onPrioridadeChange = viewModel::onPrioridadeChange,
        onSalvarPrioridade = viewModel::salvarPrioridade,
        onFeedbackChange = viewModel::onFeedbackChange,
        onAprovar = viewModel::aprovar,
        onReprovar = viewModel::reprovar,
        onUpvote = viewModel::upvote,
        onCriarProjeto = onNavigateToNovoProjeto,
        onExcluir = viewModel::excluir
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IdeiaDetalheScreenContent(
    uiState: IdeiaDetalheUiState,
    onNavigateBack: () -> Unit,
    onIniciarAnalise: () -> Unit,
    onImpactoChange: (Float) -> Unit,
    onEsforcoChange: (Float) -> Unit,
    onPrioridadeChange: (Float) -> Unit = {},
    onSalvarPrioridade: () -> Unit = {},
    onFeedbackChange: (String) -> Unit,
    onAprovar: () -> Unit,
    onReprovar: () -> Unit,
    onUpvote: () -> Unit,
    onCriarProjeto: (String) -> Unit = {},
    onExcluir: () -> Unit = {}
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val isDarkTheme = isSystemInDarkTheme()
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var celebrationMessage by remember { mutableStateOf<String?>(null) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    val actionSuccessMessage = stringResource(R.string.ideia_detalhe_acao_sucesso)
    val ideiaAprovadaMessage = "Ideia Aprovada!"

    LaunchedEffect(uiState.deleted) {
        if (uiState.deleted) {
            onNavigateBack()
        }
    }

    LaunchedEffect(uiState.actionSuccess, uiState.ideia?.status) {
        if (uiState.actionSuccess) {
            when (uiState.ideia?.status) {
                StatusIdeia.APROVADA -> celebrationMessage = ideiaAprovadaMessage
                else -> snackbarHostState.showSnackbar(actionSuccessMessage)
            }
        }
    }

    LaunchedEffect(uiState.errorMessageRes) {
        uiState.errorMessageRes?.let { messageRes ->
            snackbarHostState.showSnackbar(context.getString(messageRes))
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            AguiaTopBar(
                title = stringResource(R.string.ideia_detalhe_titulo),
                onBackClick = onNavigateBack
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { paddingValues ->
        when {
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            uiState.ideia == null -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = stringResource(R.string.cd_idea_icon),
                            modifier = Modifier.size(64.dp),
                            tint = MaterialTheme.colorScheme.outline
                        )
                        Text(
                            text = stringResource(
                                uiState.errorMessageRes ?: R.string.ideia_detalhe_nao_encontrada
                            ),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            else -> {
                val ideia = uiState.ideia
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    PremiumStatusHeaderCard(ideia = ideia, isDarkTheme = isDarkTheme)

                    PremiumIdeiaInfoCard(
                        ideia = ideia,
                        isDarkTheme = isDarkTheme
                    )

                    if (uiState.orientacao != null) {
                        PremiumOrientacaoCard(
                            orientacao = uiState.orientacao,
                            isDarkTheme = isDarkTheme
                        )
                    }

                    if (ideia.scoreIa != null &&
                        (uiState.perfil == PerfilUsuario.GESTOR || uiState.perfil == PerfilUsuario.LIDER)) {
                        PremiumIaScoreCard(
                            score = ideia.scoreIa,
                            justificativa = ideia.justificativaIa,
                            fallback = uiState.scoreFallback || ideia.scoreIaFallback,
                            isDarkTheme = isDarkTheme
                        )
                    }

                    if (uiState.isPendingEvaluation && uiState.canEvaluate) {
                        PremiumAvaliacaoSection(
                            impacto = uiState.impacto,
                            esforco = uiState.esforco,
                            prioridade = uiState.prioridade,
                            score = uiState.scorePriorizacao,
                            feedback = uiState.feedback,
                            errorMessageRes = uiState.errorMessageRes,
                            isDarkTheme = isDarkTheme,
                            onImpactoChange = onImpactoChange,
                            onEsforcoChange = onEsforcoChange,
                            onPrioridadeChange = onPrioridadeChange,
                            onSalvarPrioridade = onSalvarPrioridade,
                            onFeedbackChange = onFeedbackChange,
                            onAprovar = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onAprovar()
                            },
                            onReprovar = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onReprovar()
                            }
                        )

                        if (ideia.status == StatusIdeia.PENDENTE || ideia.status == StatusIdeia.EM_ANALISE) {
                            InovagabButton(
                                text = stringResource(R.string.ideia_detalhe_pontuar_ia),
                                onClick = onIniciarAnalise,
                                variant = InovagabButtonVariant.Neutral,
                                leadingIcon = Icons.Outlined.AutoAwesome,
                                enabled = !uiState.scoringInProgress,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    } else if (ideia.impactoEstimado > 0 || ideia.esforcoEstimado > 0) {
                        PremiumScoreCard(
                            impacto = ideia.impactoEstimado,
                            esforco = ideia.esforcoEstimado,
                            score = ideia.scorePriorizacao,
                            isDarkTheme = isDarkTheme
                        )
                    }

                    if (ideia.feedback != null) {
                        PremiumFeedbackCard(feedback = ideia.feedback, isDarkTheme = isDarkTheme)
                    }

                    if (uiState.perfil == PerfilUsuario.GESTOR && ideia.status == StatusIdeia.APROVADA) {
                        InovagabButton(
                            text = stringResource(R.string.ideia_converter_projeto),
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onCriarProjeto(ideia.id)
                            },
                            leadingIcon = Icons.Default.Folder,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (uiState.canDelete) {
                        InovagabButton(
                            text = stringResource(R.string.ideia_excluir_botao),
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                showDeleteDialog = true
                            },
                            variant = InovagabButtonVariant.Neutral,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    AnimatedVisibility(
                        visible = uiState.actionSuccess,
                        enter = fadeIn(animationSpec = tween(300)) + slideInVertically(),
                        exit = fadeOut(animationSpec = tween(300))
                    ) {
                        SuccessCard()
                    }

                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }

        if (showDeleteDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteDialog = false },
                title = { Text(stringResource(R.string.ideia_excluir_titulo)) },
                text = {
                    Text(
                        stringResource(
                            R.string.ideia_excluir_mensagem,
                            uiState.ideia?.titulo.orEmpty()
                        )
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            onExcluir()
                            showDeleteDialog = false
                        }
                    ) {
                        Text(
                            text = stringResource(R.string.ideia_excluir_confirmar),
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteDialog = false }) {
                        Text(stringResource(R.string.btn_cancelar))
                    }
                }
            )
        }

        celebrationMessage?.let { message ->
            CelebrationOverlay(
                message = message,
                visible = true,
                onDismiss = { celebrationMessage = null }
            )
        }
    }
}

@Composable
private fun PremiumStatusHeaderCard(
    ideia: Ideia,
    isDarkTheme: Boolean
) {
    val shape = RoundedCornerShape(16.dp)
    val borderColor = MaterialTheme.colorScheme.outlineVariant.copy(
        alpha = if (isDarkTheme) 0.25f else 0.4f
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (!isDarkTheme) Modifier.border(1.dp, borderColor, shape)
                    else Modifier
                )
                .padding(20.dp)
        ) {
            Text(
                text = ideia.titulo,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.semantics { heading() }
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = ideia.descricao,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = MaterialTheme.typography.bodyMedium.lineHeight * 1.35f,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ideiaStatusLabel(status: StatusIdeia): String = when (status) {
    StatusIdeia.PENDENTE -> stringResource(R.string.status_awaiting_evaluation)
    StatusIdeia.EM_ANALISE -> stringResource(R.string.status_under_analysis)
    StatusIdeia.APROVADA -> stringResource(R.string.status_idea_approved)
    StatusIdeia.REPROVADA -> stringResource(R.string.status_not_prioritized)
    StatusIdeia.CONVERTIDA_PROJETO -> stringResource(R.string.status_converted_project)
}

@Composable
private fun PremiumIdeiaInfoCard(
    ideia: Ideia,
    isDarkTheme: Boolean
) {
    val dataCriacao = remember(ideia.dataCriacao) {
        formatLongDate(ideia.dataCriacao)
    }
    val dataAvaliacao = remember(ideia.dataAvaliacao) {
        ideia.dataAvaliacao?.let { formatLongDate(it) }
    }
    val shape = RoundedCornerShape(16.dp)
    val borderColor = MaterialTheme.colorScheme.outlineVariant.copy(
        alpha = if (isDarkTheme) 0.25f else 0.4f
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .semantics(mergeDescendants = true) {},
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (!isDarkTheme) Modifier.border(1.dp, borderColor, shape)
                    else Modifier
                )
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            StatusInfoRow(
                status = ideia.status,
                isDarkTheme = isDarkTheme
            )

            InfoRow(
                icon = Icons.Default.Person,
                label = stringResource(R.string.ideia_detalhe_autor),
                value = ideia.autorNome,
                isDarkTheme = isDarkTheme
            )

            InfoRow(
                icon = Icons.Outlined.Category,
                label = stringResource(R.string.ideia_detalhe_area),
                value = stringResource(ideia.area.labelRes()),
                isDarkTheme = isDarkTheme
            )

            InfoRow(
                icon = Icons.Default.CalendarToday,
                label = stringResource(R.string.ideia_detalhe_data_criacao),
                value = dataCriacao,
                isDarkTheme = isDarkTheme
            )

            dataAvaliacao?.let { avaliacao ->
                InfoRow(
                    icon = Icons.Default.CalendarToday,
                    label = stringResource(R.string.ideia_detalhe_data_avaliacao),
                    value = avaliacao,
                    isDarkTheme = isDarkTheme
                )
            }

        }
    }
}

@Composable
private fun StatusInfoRow(
    status: StatusIdeia,
    isDarkTheme: Boolean
) {
    val statusColor = ideiaStatusColor(status)
    val statusLabel = ideiaStatusLabel(status)

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    MaterialTheme.colorScheme.primary.copy(alpha = if (isDarkTheme) 0.15f else 0.1f),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.Flag,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column {
            Text(
                text = stringResource(R.string.ideia_detalhe_status),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = statusLabel,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun PremiumOrientacaoCard(
    orientacao: OrientacaoEstrategica,
    isDarkTheme: Boolean
) {
    val accent = MaterialTheme.colorScheme.tertiary
    val shape = RoundedCornerShape(16.dp)
    val borderColor = MaterialTheme.colorScheme.outlineVariant.copy(
        alpha = if (isDarkTheme) 0.25f else 0.4f
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (!isDarkTheme) Modifier.border(1.dp, borderColor, shape)
                    else Modifier
                )
                .padding(20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        accent.copy(alpha = if (isDarkTheme) 0.18f else 0.12f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Explore,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.ideia_detalhe_orientacao_eyebrow),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = orientacao.titulo,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (orientacao.descricao.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = orientacao.descricao,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun PremiumIaScoreCard(
    score: Int,
    justificativa: String?,
    fallback: Boolean,
    isDarkTheme: Boolean
) {
    val shape = RoundedCornerShape(16.dp)
    val borderColor = MaterialTheme.colorScheme.outlineVariant.copy(
        alpha = if (isDarkTheme) 0.25f else 0.4f
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (!isDarkTheme) Modifier.border(1.dp, borderColor, shape)
                    else Modifier
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            MaterialTheme.colorScheme.primary.copy(alpha = if (isDarkTheme) 0.15f else 0.1f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AutoAwesome,
                        contentDescription = stringResource(R.string.cd_ai_suggestion),
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = stringResource(R.string.ideia_score_ia_title),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = stringResource(R.string.ideia_score_ia_label, score),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            if (fallback) {
                Text(
                    text = stringResource(R.string.ideia_score_ia_fallback),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    text = justificativa?.takeIf { it.isNotBlank() }
                        ?: stringResource(R.string.ideia_score_ia_fallback),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 6,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun InfoRow(
    icon: ImageVector,
    label: String,
    value: String,
    isDarkTheme: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(
                    MaterialTheme.colorScheme.primary.copy(alpha = if (isDarkTheme) 0.15f else 0.1f),
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun PremiumFeedbackCard(
    feedback: String,
    isDarkTheme: Boolean
) {
    val borderColor = if (isDarkTheme) {
        MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f)
    } else {
        MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)
    }
    
    val backgroundColor = if (isDarkTheme) {
        MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f)
    } else {
        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
    }
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, borderColor, RoundedCornerShape(16.dp))
            .background(backgroundColor)
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(20.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column {
                Text(
                    text = stringResource(R.string.ideia_detalhe_feedback_gestor),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = feedback,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun PremiumAvaliacaoSection(
    impacto: Float,
    esforco: Float,
    prioridade: Float,
    score: Int,
    feedback: String,
    errorMessageRes: Int?,
    isDarkTheme: Boolean,
    onImpactoChange: (Float) -> Unit,
    onEsforcoChange: (Float) -> Unit,
    onPrioridadeChange: (Float) -> Unit,
    onSalvarPrioridade: () -> Unit,
    onFeedbackChange: (String) -> Unit,
    onAprovar: () -> Unit,
    onReprovar: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val borderColor = MaterialTheme.colorScheme.outlineVariant.copy(
        alpha = if (isDarkTheme) 0.25f else 0.4f
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .semantics(mergeDescendants = true) {},
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (!isDarkTheme) Modifier.border(1.dp, borderColor, shape)
                    else Modifier
                )
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = stringResource(R.string.ideia_detalhe_avaliacao),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.semantics { heading() }
            )

            Text(
                text = stringResource(R.string.ideia_score_ia_hint),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SliderSection(
                label = stringResource(R.string.ideia_detalhe_impacto),
                value = impacto,
                onValueChange = onImpactoChange
            )
            
            SliderSection(
                label = stringResource(R.string.ideia_detalhe_esforco),
                value = esforco,
                onValueChange = onEsforcoChange
            )

            SliderSection(
                label = stringResource(R.string.ideia_detalhe_prioridade),
                value = prioridade,
                onValueChange = onPrioridadeChange,
                valueRange = 1f..100f,
                maxLabel = 100,
                steps = 98,
                onValueChangeFinished = onSalvarPrioridade
            )

            ScoreDisplay(score = score, isDarkTheme = isDarkTheme, compact = true)

            OutlinedTextField(
                value = feedback,
                onValueChange = onFeedbackChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.ideia_detalhe_feedback)) },
                placeholder = { Text(stringResource(R.string.ideia_detalhe_feedback_placeholder)) },
                shape = RoundedCornerShape(12.dp),
                minLines = 2,
                maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
            )

            errorMessageRes?.let { messageRes ->
                Text(
                    text = stringResource(messageRes),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                InovagabButton(
                    text = stringResource(R.string.action_reject),
                    onClick = onReprovar,
                    variant = InovagabButtonVariant.Neutral,
                    modifier = Modifier.weight(1f)
                )
                InovagabButton(
                    text = stringResource(R.string.action_approve),
                    onClick = onAprovar,
                    variant = InovagabButtonVariant.Success,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun SliderSection(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float> = 1f..5f,
    maxLabel: Int = 5,
    steps: Int = 3,
    onValueChangeFinished: (() -> Unit)? = null
) {
    val sliderValueDesc = stringResource(R.string.cd_slider_value, label, value.toInt())

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "${value.toInt()}/$maxLabel",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        Slider(
            value = value,
            onValueChange = onValueChange,
            onValueChangeFinished = { onValueChangeFinished?.invoke() },
            valueRange = valueRange,
            steps = steps,
            modifier = Modifier.semantics {
                contentDescription = label
                stateDescription = sliderValueDesc
            },
            colors = SliderDefaults.colors(
                thumbColor = MaterialTheme.colorScheme.primary,
                activeTrackColor = MaterialTheme.colorScheme.primary,
                inactiveTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
            )
        )
    }
}

@Composable
private fun ScoreDisplay(
    score: Int,
    isDarkTheme: Boolean,
    compact: Boolean = false
) {
    if (compact) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.ideia_detalhe_score_priorizacao),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "$score",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        return
    }

    val backgroundColor = if (isDarkTheme) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
    } else {
        MaterialTheme.colorScheme.primaryContainer
    }
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(backgroundColor)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = stringResource(R.string.ideia_detalhe_score_priorizacao),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = "$score",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
private fun PremiumScoreCard(
    impacto: Int,
    esforco: Int,
    score: Int,
    isDarkTheme: Boolean
) {
    val shape = RoundedCornerShape(16.dp)
    val borderColor = MaterialTheme.colorScheme.outlineVariant.copy(
        alpha = if (isDarkTheme) 0.25f else 0.4f
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isDarkTheme) 0.dp else 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (!isDarkTheme) Modifier.border(1.dp, borderColor, shape)
                    else Modifier
                )
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = stringResource(R.string.ideia_detalhe_priorizacao),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            ScoreDotsIndicator(
                label = stringResource(R.string.ideia_detalhe_impacto),
                value = impacto,
                color = MaterialTheme.colorScheme.primary
            )

            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
            )

            ScoreDotsIndicator(
                label = stringResource(R.string.ideia_detalhe_esforco),
                value = esforco,
                color = MaterialTheme.colorScheme.tertiary
            )

            ScoreDisplay(score = score, isDarkTheme = isDarkTheme)
        }
    }
}

@Composable
private fun ScoreDotsIndicator(
    label: String,
    value: Int,
    color: Color,
    maxValue: Int = 5
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.Top
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                repeat(maxValue) { index ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(8.dp)
                            .clip(RoundedCornerShape(100))
                            .background(
                                if (index < value) color else color.copy(alpha = 0.18f)
                            )
                    )
                }
            }
        }
        Text(
            text = "$value/$maxValue",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = color,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
private fun SuccessCard() {
    val isDarkTheme = isSystemInDarkTheme()
    val backgroundColor = if (isDarkTheme) {
        SuccessGreen.copy(alpha = 0.15f)
    } else {
        SuccessGreen.copy(alpha = 0.1f)
    }
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(backgroundColor)
            .border(1.dp, SuccessGreen.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = SuccessGreen,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = stringResource(R.string.ideia_detalhe_acao_sucesso),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = SuccessGreen
            )
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Preview(showBackground = true, showSystemUi = true, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun IdeiaDetalheGestorPendentePreview() {
    InovagabTheme {
        IdeiaDetalheScreenContent(
            uiState = IdeiaDetalheUiState(
                ideia = Ideia(
                    id = "1",
                    titulo = "Rastreamento de frota em tempo real",
                    descricao = "Usar telemetria para reduzir combustível e melhorar pontualidade das linhas.",
                    tipo = TipoIdeia.IDEIA,
                    area = AreaAtuacao.OPERACOES,
                    status = StatusIdeia.REPROVADA,
                    autorId = "user1",
                    autorNome = "Pedro Santos",
                    upvotes = 0,
                    dataAvaliacao = System.currentTimeMillis()
                ),
                orientacao = OrientacaoEstrategica(
                    id = "o1",
                    titulo = "Eficiência operacional e experiência do passageiro",
                    descricao = "Priorizar iniciativas que reduzam custos logísticos e melhorem NPS nas linhas rodoviárias.",
                    categoria = CategoriaOrientacao.EFICIENCIA_OPERACIONAL,
                    criadoPor = "lider"
                ),
                perfil = PerfilUsuario.OPERADOR
            ),
            onNavigateBack = {},
            onIniciarAnalise = {},
            onImpactoChange = {},
            onEsforcoChange = {},
            onFeedbackChange = {},
            onAprovar = {},
            onReprovar = {},
            onUpvote = {},
            onCriarProjeto = {}
        )
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun IdeiaDetalheGestorEmAnalisePreview() {
    InovagabTheme {
        IdeiaDetalheScreenContent(
            uiState = IdeiaDetalheUiState(
                ideia = Ideia(
                    id = "1",
                    titulo = "Redução de Papel",
                    descricao = "Digitalizar documentos para reduzir uso de papel em 80%.",
                    tipo = TipoIdeia.IDEIA,
                    area = AreaAtuacao.OPERACOES,
                    status = StatusIdeia.EM_ANALISE,
                    autorId = "user2",
                    autorNome = "Maria Santos"
                ),
                perfil = PerfilUsuario.GESTOR,
                impacto = 4f,
                esforco = 2f
            ),
            onNavigateBack = {},
            onIniciarAnalise = {},
            onImpactoChange = {},
            onEsforcoChange = {},
            onFeedbackChange = {},
            onAprovar = {},
            onReprovar = {},
            onUpvote = {},
            onCriarProjeto = {}
        )
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun IdeiaDetalheOperadorComFeedbackPreview() {
    InovagabTheme {
        IdeiaDetalheScreenContent(
            uiState = IdeiaDetalheUiState(
                ideia = Ideia(
                    id = "1",
                    titulo = "Melhoria no Atendimento",
                    descricao = "Criar canal digital para feedback dos passageiros.",
                    tipo = TipoIdeia.IDEIA,
                    area = AreaAtuacao.COMERCIAL,
                    status = StatusIdeia.APROVADA,
                    autorId = "user3",
                    autorNome = "Carlos Oliveira",
                    feedback = "Excelente ideia! Vamos implementar no próximo trimestre.",
                    impactoEstimado = 5,
                    esforcoEstimado = 3,
                    upvotes = 8
                ),
                perfil = PerfilUsuario.OPERADOR,
                jaVotou = true
            ),
            onNavigateBack = {},
            onIniciarAnalise = {},
            onImpactoChange = {},
            onEsforcoChange = {},
            onFeedbackChange = {},
            onAprovar = {},
            onReprovar = {},
            onUpvote = {},
            onCriarProjeto = {}
        )
    }
}

@Preview(showBackground = true, showSystemUi = true, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun IdeiaDetalheOperadorApoioPreview() {
    InovagabTheme {
        IdeiaDetalheScreenContent(
            uiState = IdeiaDetalheUiState(
                ideia = Ideia(
                    id = "2",
                    titulo = "Rastreamento de frota em tempo real",
                    descricao = "Usar telemetria para reduzir combustível e melhorar pontualidade das linhas.",
                    tipo = TipoIdeia.IDEIA,
                    area = AreaAtuacao.OPERACOES,
                    status = StatusIdeia.PENDENTE,
                    autorId = "user1",
                    autorNome = "Pedro Santos",
                    upvotes = 12
                ),
                jaVotou = false,
                perfil = PerfilUsuario.OPERADOR
            ),
            onNavigateBack = {},
            onIniciarAnalise = {},
            onImpactoChange = {},
            onEsforcoChange = {},
            onFeedbackChange = {},
            onAprovar = {},
            onReprovar = {},
            onUpvote = {},
            onCriarProjeto = {}
        )
    }
}
