package com.gtnix.aguiabranca.data.remote.dto

data class OrientacaoRequestDto(
    val titulo: String,
    val descricao: String?,
    val categoria: String,
    val campanha: String
)
