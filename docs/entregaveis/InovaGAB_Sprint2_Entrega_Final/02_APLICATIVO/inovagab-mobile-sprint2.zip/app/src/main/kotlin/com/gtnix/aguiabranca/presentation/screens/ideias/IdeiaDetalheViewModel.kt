package com.gtnix.aguiabranca.presentation.screens.ideias

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gtnix.aguiabranca.R
import com.gtnix.aguiabranca.domain.model.Ideia
import com.gtnix.aguiabranca.domain.model.OrientacaoEstrategica
import com.gtnix.aguiabranca.domain.model.PerfilUsuario
import com.gtnix.aguiabranca.domain.model.StatusIdeia
import com.gtnix.aguiabranca.domain.repository.IdeiaRepository
import com.gtnix.aguiabranca.domain.repository.OrientacaoRepository
import com.gtnix.aguiabranca.domain.session.SessionManager
import com.gtnix.aguiabranca.domain.usecase.ideia.AprovarIdeiaUseCase
import com.gtnix.aguiabranca.domain.usecase.ideia.PriorizarIdeiaUseCase
import com.gtnix.aguiabranca.domain.usecase.ideia.ScoreIdeiasUseCase
import com.gtnix.aguiabranca.domain.util.Result
import com.gtnix.aguiabranca.domain.util.isForbidden
import com.gtnix.aguiabranca.domain.util.isOffline
import com.gtnix.aguiabranca.presentation.navigation.Destination
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject

@HiltViewModel
class IdeiaDetalheViewModel @Inject constructor(
    private val ideiaRepository: IdeiaRepository,
    private val orientacaoRepository: OrientacaoRepository,
    private val aprovarIdeiaUseCase: AprovarIdeiaUseCase,
    private val priorizarIdeiaUseCase: PriorizarIdeiaUseCase,
    private val scoreIdeiasUseCase: ScoreIdeiasUseCase,
    private val sessionManager: SessionManager,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _uiState = MutableStateFlow(IdeiaDetalheUiState())
    val uiState: StateFlow<IdeiaDetalheUiState> = _uiState.asStateFlow()

    private val ideiaId: String = savedStateHandle[Destination.IdeiaDetalhe.ARG_IDEIA_ID] ?: ""

    init {
        carregarIdeia()
    }

    private fun carregarIdeia() {
        _uiState.update { it.copy(isLoading = true) }
        viewModelScope.launch {
            try {
                val ideia = ideiaRepository.buscarPorId(ideiaId)
                val user = sessionManager.getCurrentUser()
                val perfil = user?.perfil ?: PerfilUsuario.OPERADOR
                val orientacao = ideia?.orientacaoId?.let { orientacaoRepository.buscarPorId(it) }
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        ideia = ideia,
                        perfil = perfil,
                        currentUserId = user?.id,
                        orientacao = orientacao,
                        impacto = (ideia?.impactoEstimado?.takeIf { value -> value > 0 } ?: 3).toFloat(),
                        esforco = (ideia?.esforcoEstimado?.takeIf { value -> value > 0 } ?: 2).toFloat(),
                        prioridade = (ideia?.prioridade?.takeIf { value -> value in 1..100 } ?: 50).toFloat(),
                        errorMessageRes = if (ideia == null) R.string.error_load_idea else null
                    )
                }
            } catch (e: HttpException) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        ideia = null,
                        errorMessageRes = if (e.code() == 403) {
                            R.string.error_ideia_access_denied
                        } else {
                            R.string.error_load_idea
                        }
                    )
                }
            } catch (e: IOException) {
                _uiState.update { it.copy(isLoading = false, errorMessageRes = R.string.error_network_required) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, errorMessageRes = R.string.error_load_idea) }
            }
        }
    }

    fun onImpactoChange(value: Float) {
        _uiState.update { it.copy(impacto = value) }
    }

    fun onEsforcoChange(value: Float) {
        _uiState.update { it.copy(esforco = value) }
    }

    fun onPrioridadeChange(value: Float) {
        _uiState.update { it.copy(prioridade = value, errorMessageRes = null) }
    }

    fun salvarPrioridade() {
        val current = _uiState.value
        val ideia = current.ideia ?: return
        if (!current.canEvaluate || !current.isPendingEvaluation) return
        viewModelScope.launch {
            when (val result = priorizarIdeiaUseCase(ideia.id, current.prioridade.toInt())) {
                is Result.Success -> refreshIdeia(showSuccess = true)
                is Result.Error -> _uiState.update {
                    it.copy(errorMessageRes = mutationErrorRes(result, R.string.error_priority_idea))
                }
                is Result.Loading -> Unit
            }
        }
    }

    fun onFeedbackChange(text: String) {
        _uiState.update { it.copy(feedback = text, errorMessageRes = null) }
    }

    fun iniciarAnalise() {
        pontuarComIa()
    }

    fun pontuarComIa() {
        val current = _uiState.value
        val ideia = current.ideia ?: return
        val orientacaoId = ideia.orientacaoId
        if (!current.canEvaluate || orientacaoId.isNullOrBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(scoringInProgress = true, errorMessageRes = null) }
            when (val result = scoreIdeiasUseCase(orientacaoId, listOf(ideia.id))) {
                is Result.Success -> refreshIdeia(
                    showSuccess = true,
                    scoreFallback = result.data.fallback
                )
                is Result.Error -> {
                    _uiState.update {
                        it.copy(
                            scoringInProgress = false,
                            errorMessageRes = mutationErrorRes(result, R.string.error_score_ideas)
                        )
                    }
                }
                is Result.Loading -> Unit
            }
        }
    }

    fun upvote() {
        if (_uiState.value.jaVotou) return
        viewModelScope.launch {
            try {
                ideiaRepository.incrementUpvote(ideiaId)
                val atualizada = ideiaRepository.buscarPorId(ideiaId)
                _uiState.update { it.copy(ideia = atualizada, jaVotou = true) }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessageRes = R.string.error_upvote_idea) }
            }
        }
    }

    fun aprovar() {
        val current = _uiState.value
        val ideia = current.ideia ?: return
        if (!current.canEvaluate || !current.isPendingEvaluation) return
        viewModelScope.launch {
            when (
                val result = aprovarIdeiaUseCase(
                    ideiaId = ideia.id,
                    aprovada = true,
                    feedback = current.feedback.ifBlank { null },
                    impactoEstimado = current.impacto.toInt(),
                    esforcoEstimado = current.esforco.toInt()
                )
            ) {
                is Result.Success -> refreshIdeia(showSuccess = true)
                is Result.Error -> {
                    _uiState.update {
                        it.copy(errorMessageRes = mutationErrorRes(result, R.string.error_approve_idea))
                    }
                }
                is Result.Loading -> Unit
            }
        }
    }

    fun reprovar() {
        val current = _uiState.value
        val ideia = current.ideia ?: return
        if (!current.canEvaluate || !current.isPendingEvaluation) return
        if (current.feedback.isBlank()) {
            _uiState.update { it.copy(errorMessageRes = R.string.error_feedback_required_reject) }
            return
        }
        viewModelScope.launch {
            when (
                val result = aprovarIdeiaUseCase(
                    ideiaId = ideia.id,
                    aprovada = false,
                    feedback = current.feedback,
                    impactoEstimado = current.impacto.toInt(),
                    esforcoEstimado = current.esforco.toInt()
                )
            ) {
                is Result.Success -> refreshIdeia(showSuccess = true)
                is Result.Error -> {
                    _uiState.update {
                        it.copy(errorMessageRes = mutationErrorRes(result, R.string.error_reject_idea))
                    }
                }
                is Result.Loading -> Unit
            }
        }
    }

    fun excluir() {
        val current = _uiState.value
        if (!current.canDelete) return
        viewModelScope.launch {
            try {
                ideiaRepository.excluir(ideiaId)
                _uiState.update { it.copy(deleted = true, errorMessageRes = null) }
            } catch (e: IOException) {
                _uiState.update { it.copy(errorMessageRes = R.string.error_network_required) }
            } catch (e: HttpException) {
                _uiState.update {
                    it.copy(
                        errorMessageRes = if (e.code() == 403) {
                            R.string.error_ideia_access_denied
                        } else {
                            R.string.error_delete_ideia
                        }
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessageRes = R.string.error_delete_ideia) }
            }
        }
    }

    private suspend fun refreshIdeia(showSuccess: Boolean = false, scoreFallback: Boolean = false) {
        val atualizada = ideiaRepository.buscarPorId(ideiaId)
        val orientacao = atualizada?.orientacaoId?.let { orientacaoRepository.buscarPorId(it) }
        _uiState.update {
            it.copy(
                ideia = atualizada,
                orientacao = orientacao,
                prioridade = atualizada?.prioridade?.takeIf { value -> value in 1..100 }?.toFloat()
                    ?: it.prioridade,
                actionSuccess = showSuccess,
                scoringInProgress = false,
                scoreFallback = scoreFallback || (atualizada?.scoreIaFallback == true),
                errorMessageRes = null
            )
        }
    }

    private fun mutationErrorRes(result: Result.Error, fallback: Int): Int = when {
        result.isForbidden() -> R.string.error_ideia_access_denied
        result.isOffline() -> R.string.error_network_required
        else -> fallback
    }
}

data class IdeiaDetalheUiState(
    val isLoading: Boolean = false,
    val ideia: Ideia? = null,
    val perfil: PerfilUsuario = PerfilUsuario.OPERADOR,
    val currentUserId: String? = null,
    val orientacao: OrientacaoEstrategica? = null,
    val impacto: Float = 3f,
    val esforco: Float = 2f,
    val prioridade: Float = 50f,
    val feedback: String = "",
    val errorMessageRes: Int? = null,
    val actionSuccess: Boolean = false,
    val scoringInProgress: Boolean = false,
    val scoreFallback: Boolean = false,
    val jaVotou: Boolean = false,
    val deleted: Boolean = false
) {
    val scorePriorizacao: Int
        get() = impacto.toInt() - esforco.toInt()

    val canEvaluate: Boolean
        get() = perfil == PerfilUsuario.GESTOR

    val canDelete: Boolean
        get() = perfil == PerfilUsuario.OPERADOR
            && ideia != null
            && ideia.autorId == currentUserId

    val isPendingEvaluation: Boolean
        get() = ideia?.status == StatusIdeia.PENDENTE || ideia?.status == StatusIdeia.EM_ANALISE
}
