package com.gtnix.aguiabranca.domain.model

data class RankingIdeia(
    val ideiaId: String,
    val score: Int,
    val justificativa: String
)

data class ScoreIdeiasResult(
    val ranking: List<RankingIdeia>,
    val modelo: String,
    val fallback: Boolean
)
