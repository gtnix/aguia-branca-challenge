package com.gtnix.aguiabranca.data.remote.dto

import com.gtnix.aguiabranca.data.util.safeValueOf
import com.gtnix.aguiabranca.domain.model.AreaAtuacao
import com.gtnix.aguiabranca.domain.model.Ideia
import com.gtnix.aguiabranca.domain.model.RankingIdeia
import com.gtnix.aguiabranca.domain.model.ScoreIdeiasResult
import com.gtnix.aguiabranca.domain.model.StatusIdeia
import com.gtnix.aguiabranca.domain.model.TipoIdeia
import java.time.Instant

fun IdeiaDto.toDomain(): Ideia {
    val criado = parseIsoToEpoch(dataCriacao)
    val statusDominio = safeValueOf(status.orEmpty(), StatusIdeia.PENDENTE)
    val avaliada = statusDominio == StatusIdeia.APROVADA || statusDominio == StatusIdeia.REPROVADA
    return Ideia(
        id = id,
        titulo = titulo,
        descricao = descricao.orEmpty(),
        tipo = safeValueOf(tipo.orEmpty(), TipoIdeia.IDEIA),
        area = safeValueOf(area.orEmpty(), AreaAtuacao.OPERACOES),
        status = statusDominio,
        autorId = autorUserId.orEmpty(),
        autorNome = autorNome?.takeIf { it.isNotBlank() } ?: autorUserId.orEmpty(),
        orientacaoId = orientacaoId,
        feedback = feedbackReprovacao,
        dataCriacao = criado,
        dataAvaliacao = if (avaliada) parseIsoToEpoch(dataAtualizacao) else null,
        impactoEstimado = impacto ?: 0,
        esforcoEstimado = esforco ?: 0,
        prioridade = prioridade,
        scoreIa = scoreIa,
        justificativaIa = justificativaIa,
        scoreIaFallback = scoreIaFallback == true
    )
}

fun Ideia.toRequestDto(): IdeiaRequestDto = IdeiaRequestDto(
    titulo = titulo,
    descricao = descricao,
    tipo = tipo.name,
    area = area.name,
    orientacaoId = requireNotNull(orientacaoId?.takeIf { it.isNotBlank() }) {
        "orientacaoId obrigatório"
    },
    impacto = impactoEstimado.takeIf { it > 0 },
    esforco = esforcoEstimado.takeIf { it > 0 }
)

fun ScoreIdeasResponseDto.toDomain(): ScoreIdeiasResult = ScoreIdeiasResult(
    ranking = ranking.map {
        RankingIdeia(
            ideiaId = it.ideiaId,
            score = it.score,
            justificativa = it.justificativa.orEmpty()
        )
    },
    modelo = modelo.orEmpty(),
    fallback = fallback
)

private fun parseIsoToEpoch(value: String?): Long {
    if (value.isNullOrBlank()) return System.currentTimeMillis()
    return runCatching { Instant.parse(value).toEpochMilli() }.getOrDefault(System.currentTimeMillis())
}
