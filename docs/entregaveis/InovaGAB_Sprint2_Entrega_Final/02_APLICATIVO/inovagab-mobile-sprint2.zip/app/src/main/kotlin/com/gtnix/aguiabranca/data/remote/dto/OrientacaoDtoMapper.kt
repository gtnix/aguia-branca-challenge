package com.gtnix.aguiabranca.data.remote.dto

import com.gtnix.aguiabranca.data.util.safeValueOf
import com.gtnix.aguiabranca.domain.model.CategoriaOrientacao
import com.gtnix.aguiabranca.domain.model.OrientacaoEstrategica
import java.time.Instant

fun OrientacaoDto.toDomain(): OrientacaoEstrategica {
    val campanhaValor = campanha.orEmpty()
    return OrientacaoEstrategica(
        id = id,
        titulo = titulo,
        descricao = descricao.orEmpty(),
        categoria = safeValueOf(categoria, CategoriaOrientacao.EFICIENCIA_OPERACIONAL),
        prioridade = parsePrioridade(campanhaValor),
        ativa = ativo,
        criadoPor = criadoPorUserId.orEmpty(),
        dataCriacao = parseIsoToEpoch(dataCriacao),
        campanha = campanhaValor
    )
}

fun OrientacaoEstrategica.toRequestDto(): OrientacaoRequestDto = OrientacaoRequestDto(
    titulo = titulo,
    descricao = descricao,
    categoria = categoria.name,
    campanha = campanha.ifBlank { "P$prioridade" }
)

private fun parseIsoToEpoch(value: String?): Long {
    if (value.isNullOrBlank()) return System.currentTimeMillis()
    return runCatching { Instant.parse(value).toEpochMilli() }.getOrDefault(System.currentTimeMillis())
}

private fun parsePrioridade(campanha: String): Int {
    val match = Regex("""P([1-5])""").find(campanha)
    return match?.groupValues?.get(1)?.toIntOrNull() ?: 3
}
