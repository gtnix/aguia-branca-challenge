package com.gtnix.aguiabranca.data.remote.dto

data class IdeiaDto(
    val id: String,
    val autorUserId: String? = null,
    val autorNome: String? = null,
    val titulo: String,
    val descricao: String? = null,
    val tipo: String? = null,
    val area: String? = null,
    val orientacaoId: String? = null,
    val status: String? = null,
    val prioridade: Int? = null,
    val impacto: Int? = null,
    val esforco: Int? = null,
    val scoreIa: Int? = null,
    val justificativaIa: String? = null,
    val scoreIaFallback: Boolean? = null,
    val feedbackReprovacao: String? = null,
    val dataCriacao: String? = null,
    val dataAtualizacao: String? = null
)

data class IdeiaRequestDto(
    val titulo: String,
    val descricao: String,
    val tipo: String,
    val area: String,
    val orientacaoId: String,
    val impacto: Int? = null,
    val esforco: Int? = null
)

data class AvaliacaoRequestDto(
    val status: String,
    val feedback: String? = null
)

data class PrioridadeRequestDto(
    val prioridade: Int
)

data class ScoreIdeasRequestDto(
    val orientacaoId: String,
    val ideiaIds: List<String>
)

data class IdeaScoreItemDto(
    val ideiaId: String,
    val score: Int,
    val justificativa: String? = null
)

data class ScoreIdeasResponseDto(
    val ranking: List<IdeaScoreItemDto> = emptyList(),
    val modelo: String? = null,
    val fallback: Boolean = false
)
