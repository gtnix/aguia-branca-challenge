package com.gtnix.aguiabranca.presentation.components

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.gtnix.aguiabranca.R
import com.gtnix.aguiabranca.presentation.theme.InovagabTheme
import com.gtnix.aguiabranca.presentation.theme.SuccessGreen

@Composable
fun StatsGridOperador(
    totalIdeias: Int,
    ideiasAprovadas: Int,
    posicaoRanking: Int?,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PerfilIndicatorCard(
            label = stringResource(R.string.perfil_stat_ideias_enviadas),
            value = totalIdeias.toString(),
            icon = Icons.Default.Lightbulb,
            iconAccent = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f)
        )

        PerfilIndicatorCard(
            label = stringResource(R.string.perfil_stat_aprovadas),
            value = ideiasAprovadas.toString(),
            icon = Icons.AutoMirrored.Filled.TrendingUp,
            iconAccent = SuccessGreen,
            modifier = Modifier.weight(1f)
        )

        if (posicaoRanking != null) {
            PerfilIndicatorCard(
                label = stringResource(R.string.perfil_stat_ranking),
                value = "#$posicaoRanking",
                icon = Icons.Default.Leaderboard,
                iconAccent = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun StatsGridOperadorPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            StatsGridOperador(
                totalIdeias = 7,
                ideiasAprovadas = 4,
                posicaoRanking = 2,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}

@Preview(name = "Dark", uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun StatsGridOperadorDarkPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            StatsGridOperador(
                totalIdeias = 7,
                ideiasAprovadas = 4,
                posicaoRanking = null,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}
