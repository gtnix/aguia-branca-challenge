package com.gtnix.aguiabranca.presentation.screens.orientacoes

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PriorityHigh
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gtnix.aguiabranca.R
import com.gtnix.aguiabranca.domain.model.OrientacaoEstrategica
import com.gtnix.aguiabranca.presentation.components.AguiaTopBar
import com.gtnix.aguiabranca.presentation.util.orientacaoCategoriaColor
import com.gtnix.aguiabranca.presentation.util.orientacaoCategoriaIcon
import com.gtnix.aguiabranca.presentation.util.orientacaoCategoriaLabel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrientacaoDetalheScreen(
    viewModel: OrientacaoDetalheViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            AguiaTopBar(
                title = stringResource(R.string.orientacao_detalhe_title),
                onBackClick = onNavigateBack
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        when {
            uiState.isLoading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            }
            uiState.errorMessageRes != null -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(uiState.errorMessageRes!!),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            uiState.orientacao != null -> {
                OrientacaoDetalheContent(
                    orientacao = uiState.orientacao!!,
                    ideiasAlinhadasCount = uiState.ideiasAlinhadas.size,
                    projetosEmAndamento = uiState.projetosEmAndamento,
                    modifier = Modifier.padding(paddingValues)
                )
            }
        }
    }
}

@Composable
private fun OrientacaoDetalheContent(
    orientacao: OrientacaoEstrategica,
    ideiasAlinhadasCount: Int,
    projetosEmAndamento: Int,
    modifier: Modifier = Modifier
) {
    val isDarkTheme = isSystemInDarkTheme()
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
    val categoriaAccent = orientacaoCategoriaColor(orientacao.categoria)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isDarkTheme) 0.dp else 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(
                                    categoriaAccent.copy(alpha = if (isDarkTheme) 0.18f else 0.12f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = orientacaoCategoriaIcon(orientacao.categoria),
                                contentDescription = null,
                                tint = categoriaAccent,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Text(
                            text = orientacaoCategoriaLabel(orientacao.categoria),
                            style = MaterialTheme.typography.labelLarge,
                            color = categoriaAccent,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                    }
                    OrientacaoStatusBadge(ativa = orientacao.ativa)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = orientacao.titulo,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 20.dp),
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                )

                SectionLabel(
                    icon = Icons.Default.Info,
                    label = stringResource(R.string.orientacao_detalhe_descricao)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = orientacao.descricao,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = MaterialTheme.typography.bodyLarge.lineHeight * 1.15f
                )

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 20.dp),
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                )

                SectionLabel(
                    icon = Icons.Default.Lightbulb,
                    label = stringResource(R.string.orientacao_detalhe_impacto)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ImpactoRow(
                        icon = Icons.Default.Lightbulb,
                        label = when (ideiasAlinhadasCount) {
                            1 -> stringResource(R.string.orientacao_detalhe_ideia_alinhada)
                            else -> stringResource(
                                R.string.orientacao_detalhe_ideias_alinhadas,
                                ideiasAlinhadasCount
                            )
                        }
                    )
                    if (projetosEmAndamento > 0) {
                        ImpactoRow(
                            icon = Icons.Default.Folder,
                            label = when (projetosEmAndamento) {
                                1 -> stringResource(R.string.orientacao_detalhe_projeto_andamento)
                                else -> stringResource(
                                    R.string.orientacao_detalhe_projetos_andamento,
                                    projetosEmAndamento
                                )
                            }
                        )
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 20.dp),
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                )

                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    InfoRow(
                        icon = Icons.Default.PriorityHigh,
                        label = stringResource(R.string.orientacao_detalhe_prioridade),
                        value = prioridadeLabel(orientacao.prioridade),
                        valueColor = prioridadeColor(orientacao.prioridade)
                    )

                    InfoRow(
                        icon = Icons.Outlined.Category,
                        label = stringResource(R.string.orientacao_detalhe_categoria),
                        value = orientacaoCategoriaLabel(orientacao.categoria)
                    )

                    if (orientacao.campanha.isNotBlank()) {
                        InfoRow(
                            icon = Icons.Default.Flag,
                            label = stringResource(R.string.orientacao_detalhe_campanha),
                            value = orientacao.campanha
                        )
                    }

                    InfoRow(
                        icon = Icons.Default.CalendarToday,
                        label = stringResource(R.string.orientacao_detalhe_criado_em),
                        value = dateFormat.format(Date(orientacao.dataCriacao))
                    )

                    orientacao.dataExpiracao?.let { expiracao ->
                        InfoRow(
                            icon = Icons.Default.Flag,
                            label = stringResource(R.string.orientacao_detalhe_expira_em),
                            value = dateFormat.format(Date(expiracao)),
                            valueColor = if (expiracao < System.currentTimeMillis()) {
                                MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
private fun ImpactoRow(
    icon: ImageVector,
    label: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun SectionLabel(icon: ImageVector, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun InfoRow(
    icon: ImageVector,
    label: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.38f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = valueColor,
            textAlign = TextAlign.End,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(0.62f)
        )
    }
}

@Composable
private fun OrientacaoStatusBadge(ativa: Boolean) {
    val color = if (ativa) Color(0xFF4CAF50) else MaterialTheme.colorScheme.onSurfaceVariant
    val label = if (ativa) {
        stringResource(R.string.orientacao_ativa)
    } else {
        stringResource(R.string.orientacao_inativa)
    }

    Box(
        modifier = Modifier
            .widthIn(min = 48.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = color,
            maxLines = 1
        )
    }
}

@Composable
private fun prioridadeColor(prioridade: Int): Color = when {
    prioridade <= 1 -> MaterialTheme.colorScheme.error
    prioridade == 2 -> Color(0xFFFF9800)
    else -> Color(0xFF4CAF50)
}

private fun prioridadeLabel(prioridade: Int): String = when {
    prioridade <= 1 -> "Crítica"
    prioridade == 2 -> "Alta"
    prioridade == 3 -> "Média"
    else -> "Baixa"
}
