package com.gtnix.aguiabranca.presentation.components

import android.content.res.Configuration
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gtnix.aguiabranca.domain.model.DashboardInsight
import com.gtnix.aguiabranca.presentation.theme.AISpark
import com.gtnix.aguiabranca.presentation.theme.InovagabTheme

/**
 * Card de insight de IA para o Resumo Executivo.
 *
 * - **Compacto**: título + resumo + badge de origem.
 * - **Expandido**: evidências numéricas + ação recomendada.
 * - O estado de loading exibe um skeleton animado.
 * - Fallback exibe badge "Análise automática" em vez de "Gemini".
 */
@Composable
fun ExecutiveAiInsightCard(
    insight: DashboardInsight,
    isLoading: Boolean,
    modifier: Modifier = Modifier
) {
    val isDarkTheme = isSystemInDarkTheme()
    var expanded by remember { mutableStateOf(false) }

    val shape = RoundedCornerShape(20.dp)
    val backgroundColor = if (isDarkTheme)
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    else
        MaterialTheme.colorScheme.surface
    val borderColor = AISpark.copy(alpha = if (isDarkTheme) 0.3f else 0.2f)

    val cardModifier = modifier
        .clip(shape)
        .background(backgroundColor)
        .border(1.dp, borderColor, shape)

    Box(modifier = cardModifier.padding(16.dp)) {
        Column {
            // Header row: icon + title + expand toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(AISpark.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AutoAwesome,
                        contentDescription = null,
                        tint = AISpark,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    if (isLoading || insight.titulo.isBlank()) {
                        SkeletonText(
                            modifier = Modifier.fillMaxWidth(0.75f),
                            lineHeight = 16.dp
                        )
                    } else {
                        Text(
                            text = insight.titulo,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            modifier = Modifier.semantics { heading() }
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    // Model badge
                    InsightBadge(
                        isFallback = insight.isFallback,
                        isLoading = isLoading
                    )
                }

                if (!isLoading && insight.titulo.isNotBlank()) {
                    IconButton(
                        onClick = { expanded = !expanded },
                        modifier = Modifier
                            .size(36.dp)
                            .clearAndSetSemantics {
                                contentDescription = if (expanded) "Recolher insight" else "Expandir insight"
                            }
                    ) {
                        Icon(
                            imageVector = if (expanded) Icons.Default.KeyboardArrowUp
                            else Icons.Default.KeyboardArrowDown,
                            contentDescription = null,
                            tint = AISpark,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Resumo — always visible
            if (isLoading) {
                SkeletonText(lines = 2, lineHeight = 14.dp)
            } else if (insight.resumo.isNotBlank()) {
                Text(
                    text = insight.resumo,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 22.sp
                )
            }

            // Expanded section: evidências + ação
            AnimatedVisibility(
                visible = expanded && !isLoading && insight.evidencias.isNotEmpty(),
                enter = fadeIn(tween(200)) + expandVertically(tween(200)),
                exit = fadeOut(tween(150)) + shrinkVertically(tween(150))
            ) {
                Column {
                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = AISpark.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(12.dp))

                    if (insight.evidencias.isNotEmpty()) {
                        Text(
                            text = "Evidências",
                            style = MaterialTheme.typography.labelSmall,
                            color = AISpark,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        insight.evidencias.forEach { evidencia ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Circle,
                                    contentDescription = null,
                                    tint = AISpark,
                                    modifier = Modifier.size(6.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = evidencia,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    if (insight.acaoRecomendada.isNotBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Ação recomendada",
                            style = MaterialTheme.typography.labelSmall,
                            color = AISpark,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = insight.acaoRecomendada,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 20.sp
                        )
                    }

                    if (insight.geradoEm != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Gerado em ${insight.geradoEm.take(16).replace("T", " ")}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InsightBadge(isFallback: Boolean, isLoading: Boolean) {
    if (isLoading) {
        SkeletonText(modifier = Modifier.fillMaxWidth(0.35f), lineHeight = 10.dp)
        return
    }
    val label = if (isFallback) "Análise automática" else "Gemini"
    val color = if (isFallback)
        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
    else
        AISpark
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (!isFallback) {
            Icon(
                imageVector = Icons.Outlined.AutoAwesome,
                contentDescription = null,
                tint = AISpark,
                modifier = Modifier.size(10.dp)
            )
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontSize = 10.sp
        )
    }
}

@Preview(name = "Light Mode — compacto")
@Preview(name = "Dark Mode — compacto", uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun ExecutiveAiInsightCardPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            ExecutiveAiInsightCard(
                insight = DashboardInsight(
                    titulo = "ROI sólido com gargalo na conversão",
                    resumo = "O portfólio conta com 7 ideias ativas e ROI de 28% a.a. Há 2 ideias aprovadas aguardando conversão em projeto.",
                    evidencias = listOf("ROI de 28% a.a.", "2 ideias aprovadas sem projeto", "3 projetos no prazo"),
                    acaoRecomendada = "Converter as 2 ideias aprovadas em projetos ainda este trimestre.",
                    modelo = "gemini-3.6-flash",
                    isFallback = false,
                    geradoEm = "2026-09-21T21:59:47Z"
                ),
                isLoading = false,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )
        }
    }
}

@Preview(name = "Loading")
@Composable
private fun ExecutiveAiInsightCardLoadingPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            ExecutiveAiInsightCard(
                insight = DashboardInsight.vazio,
                isLoading = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )
        }
    }
}

@Preview(name = "Fallback")
@Composable
private fun ExecutiveAiInsightCardFallbackPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            ExecutiveAiInsightCard(
                insight = DashboardInsight(
                    titulo = "Resumo automático do portfólio",
                    resumo = "O portfólio conta com 7 ideias ativas e ROI de 28% a.a. Acompanhe a conversão de ideias aprovadas.",
                    evidencias = listOf("ROI de 28% a.a.", "7 ideias ativas"),
                    acaoRecomendada = "Converter as ideias aprovadas em projetos.",
                    modelo = "heuristic-local",
                    isFallback = true,
                    geradoEm = null
                ),
                isLoading = false,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )
        }
    }
}
