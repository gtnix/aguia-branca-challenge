package com.gtnix.aguiabranca.presentation.screens.leader

import android.content.res.Configuration
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gtnix.aguiabranca.R
import com.gtnix.aguiabranca.domain.model.DashboardInsight
import com.gtnix.aguiabranca.domain.model.FunnelStepMetric
import com.gtnix.aguiabranca.domain.model.OrientacaoEstrategica
import com.gtnix.aguiabranca.domain.usecase.dashboard.AreaDesempenhoMetric
import com.gtnix.aguiabranca.presentation.components.AguiaTopBar
import com.gtnix.aguiabranca.presentation.components.BarChartData
import com.gtnix.aguiabranca.presentation.components.EmptyState
import com.gtnix.aguiabranca.presentation.components.ExecutiveAiInsightCard
import com.gtnix.aguiabranca.presentation.components.ExecutiveKpiGrid
import com.gtnix.aguiabranca.presentation.components.FinanceiroMiniCard
import com.gtnix.aguiabranca.presentation.components.GlassCard
import com.gtnix.aguiabranca.presentation.components.HorizontalBarChart
import com.gtnix.aguiabranca.presentation.components.InovagabButton
import com.gtnix.aguiabranca.presentation.components.InovagabButtonVariant
import com.gtnix.aguiabranca.presentation.components.SectionHeader
import com.gtnix.aguiabranca.presentation.components.SkeletonLoader
import com.gtnix.aguiabranca.presentation.components.SkeletonMetricCard
import com.gtnix.aguiabranca.presentation.components.SkeletonText
import com.gtnix.aguiabranca.presentation.components.charts.FunnelChartHorizontal
import com.gtnix.aguiabranca.presentation.components.charts.FunnelStep
import com.gtnix.aguiabranca.presentation.theme.AISpark
import com.gtnix.aguiabranca.presentation.theme.InovagabTheme
import com.gtnix.aguiabranca.presentation.theme.ScreenPadding
import com.gtnix.aguiabranca.presentation.theme.SuccessGreen
import com.gtnix.aguiabranca.presentation.util.formatPercent
import kotlinx.coroutines.delay

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

@Composable
fun LeaderDashboardScreen(
    viewModel: LeaderDashboardViewModel,
    onNavigateToHome: () -> Unit,
    onNavigateToIdeias: () -> Unit,
    onNavigateToProjetos: () -> Unit,
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val orientacoes by viewModel.orientacoes.collectAsStateWithLifecycle()
    val selectedOrientacaoId by viewModel.selectedOrientacaoId.collectAsStateWithLifecycle()

    LeaderDashboardContent(
        uiState = uiState,
        orientacoes = orientacoes,
        selectedOrientacaoId = selectedOrientacaoId.takeIf { it.isNotBlank() },
        onFilterSelect = viewModel::selectOrientacao,
        onRefresh = viewModel::refresh,
        onNavigateToHome = onNavigateToHome,
        onNavigateToIdeias = onNavigateToIdeias,
        onNavigateToProjetos = onNavigateToProjetos
    )
}

// ---------------------------------------------------------------------------
// Content
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LeaderDashboardContent(
    uiState: LeaderDashboardUiState,
    orientacoes: List<OrientacaoEstrategica>,
    selectedOrientacaoId: String?,
    onFilterSelect: (String?) -> Unit,
    onRefresh: () -> Unit,
    onNavigateToHome: () -> Unit,
    onNavigateToIdeias: () -> Unit,
    onNavigateToProjetos: () -> Unit
) {
    val pullRefreshState = rememberPullToRefreshState()

    PullToRefreshBox(
        isRefreshing = uiState.isRefreshing,
        onRefresh = onRefresh,
        state = pullRefreshState,
        modifier = Modifier.fillMaxSize()
    ) {
        when {
            uiState.isLoading && !uiState.isRefreshing -> LeaderDashboardSkeleton(
                onNavigateToHome = onNavigateToHome
            )

            uiState.errorMessageRes != null && !uiState.isRefreshing -> LeaderDashboardError(
                messageRes = uiState.errorMessageRes,
                onNavigateToHome = onNavigateToHome,
                onRetry = onRefresh
            )

            else -> LeaderDashboardBody(
                uiState = uiState,
                orientacoes = orientacoes,
                selectedOrientacaoId = selectedOrientacaoId,
                onFilterSelect = onFilterSelect,
                onNavigateToHome = onNavigateToHome,
                onNavigateToIdeias = onNavigateToIdeias,
                onNavigateToProjetos = onNavigateToProjetos
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Main body
// ---------------------------------------------------------------------------

@Composable
private fun LeaderDashboardBody(
    uiState: LeaderDashboardUiState,
    orientacoes: List<OrientacaoEstrategica>,
    selectedOrientacaoId: String?,
    onFilterSelect: (String?) -> Unit,
    onNavigateToHome: () -> Unit,
    onNavigateToIdeias: () -> Unit,
    onNavigateToProjetos: () -> Unit
) {
    val isDarkTheme = isSystemInDarkTheme()
    var contentVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { contentVisible = true }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 40.dp)
    ) {
        // Top bar
        item {
            AguiaTopBar(
                title = stringResource(R.string.leader_resumo_executivo),
                onBackClick = onNavigateToHome
            )
        }

        // Strategy filter chips
        if (orientacoes.isNotEmpty()) {
            item {
                AnimatedSection(visible = contentVisible, delayMillis = 60) {
                    StrategyFilterRow(
                        orientacoes = orientacoes,
                        selectedId = selectedOrientacaoId,
                        onSelect = onFilterSelect,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
        }

        // IA insight card
        item {
            AnimatedSection(visible = contentVisible, delayMillis = 80) {
                ExecutiveAiInsightCard(
                    insight = uiState.insight,
                    isLoading = uiState.isInsightLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = ScreenPadding.Horizontal)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }

        // Primary KPI bento grid
        item {
            AnimatedSection(visible = contentVisible, delayMillis = 120) {
                SectionHeader(
                    title = stringResource(R.string.leader_kpis_titulo),
                    modifier = Modifier.padding(horizontal = ScreenPadding.Horizontal)
                )
                Spacer(modifier = Modifier.height(12.dp))
                ExecutiveKpiGrid(
                    roiPercent = uiState.roiMedio,
                    lucroAnualizado = uiState.lucroAnualizado,
                    projetosAtrasados = uiState.projetosAtrasados,
                    tempoMedioAprovacaoDias = uiState.tempoMedio,
                    onNavigateToProjetos = onNavigateToProjetos,
                    modifier = Modifier.padding(horizontal = ScreenPadding.Horizontal)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }

        // Funnel section
        item {
            AnimatedSection(visible = contentVisible, delayMillis = 160) {
                FunnelSection(
                    funil = uiState.funil,
                    totalIdeias = uiState.totalIdeias,
                    ideiasAprovadas = uiState.ideiasAprovadas,
                    ideiasEmProjeto = uiState.ideiasEmProjeto,
                    taxaAprovacaoPercent = uiState.taxaAprovacaoPercent,
                    taxaConversaoPercent = uiState.taxaConversaoPercent,
                    onNavigateToIdeias = onNavigateToIdeias,
                    onNavigateToProjetos = onNavigateToProjetos,
                    modifier = Modifier.padding(horizontal = ScreenPadding.Horizontal)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }

        // Financial section
        item {
            AnimatedSection(visible = contentVisible, delayMillis = 200) {
                FinancialSection(
                    investimentoTotal = uiState.investimentoTotal,
                    retornoMensal = uiState.retornoMensal,
                    lucroAnualizado = uiState.lucroAnualizado,
                    isDarkTheme = isDarkTheme,
                    modifier = Modifier.padding(horizontal = ScreenPadding.Horizontal)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }

        // Portfolio execution section
        item {
            AnimatedSection(visible = contentVisible, delayMillis = 230) {
                PortfolioExecutionSection(
                    projetosNoPrazo = uiState.projetosNoPrazo,
                    projetosAtrasados = uiState.projetosAtrasados,
                    progressoMedioProjetos = uiState.progressoMedioProjetos,
                    projetosAtivos = uiState.projetosAtivos,
                    isDarkTheme = isDarkTheme,
                    onNavigateToProjetos = onNavigateToProjetos,
                    modifier = Modifier.padding(horizontal = ScreenPadding.Horizontal)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }

        // Area participation section
        if (uiState.desempenhoAreas.isNotEmpty()) {
            item {
                AnimatedSection(visible = contentVisible, delayMillis = 260) {
                    AreaParticipationSection(
                        areas = uiState.desempenhoAreas,
                        isDarkTheme = isDarkTheme,
                        modifier = Modifier.padding(horizontal = ScreenPadding.Horizontal)
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Section: Strategy filter
// ---------------------------------------------------------------------------

@Composable
private fun StrategyFilterRow(
    orientacoes: List<OrientacaoEstrategica>,
    selectedId: String?,
    onSelect: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = ScreenPadding.Horizontal, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // "All" chip
        FilterChip(
            selected = selectedId == null,
            onClick = { onSelect(null) },
            label = { Text("Portfólio geral", style = MaterialTheme.typography.labelMedium) },
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primary,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
            )
        )
        orientacoes.forEach { orientacao ->
            FilterChip(
                selected = selectedId == orientacao.id,
                onClick = { onSelect(orientacao.id) },
                label = {
                    Text(
                        text = orientacao.titulo.take(24).let {
                            if (orientacao.titulo.length > 24) "$it…" else it
                        },
                        style = MaterialTheme.typography.labelMedium
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Section: Funnel
// ---------------------------------------------------------------------------

@Composable
private fun FunnelSection(
    funil: List<FunnelStepMetric>,
    totalIdeias: Int,
    ideiasAprovadas: Int,
    ideiasEmProjeto: Int,
    taxaAprovacaoPercent: Int,
    taxaConversaoPercent: Int,
    onNavigateToIdeias: () -> Unit,
    onNavigateToProjetos: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = listOf(
        MaterialTheme.colorScheme.primary,
        SuccessGreen,
        MaterialTheme.colorScheme.tertiary
    )
    val funnelSteps = funil.ifEmpty {
        listOf(
            FunnelStepMetric("IDEIAS", "Ideias", totalIdeias),
            FunnelStepMetric("APROVADAS", "Aprovadas", ideiasAprovadas),
            FunnelStepMetric("EM_PROJETO", "Em Projeto", ideiasEmProjeto)
        )
    }

    GlassCard(modifier = modifier.fillMaxWidth()) {
        Column {
            SectionHeader(title = stringResource(R.string.dashboard_funil))
            Spacer(modifier = Modifier.height(16.dp))

            FunnelChartHorizontal(
                steps = funnelSteps.mapIndexed { i, step ->
                    FunnelStep(
                        label = step.label,
                        value = step.quantidade,
                        color = colors[i % colors.size]
                    )
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Conversion rates
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ConversionRate(
                    label = "Taxa de aprovação",
                    rate = taxaAprovacaoPercent,
                    color = SuccessGreen,
                    modifier = Modifier.weight(1f)
                )
                ConversionRate(
                    label = "Taxa de conversão",
                    rate = taxaConversaoPercent,
                    color = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // CTAs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                InovagabButton(
                    text = "Ver ideias",
                    onClick = onNavigateToIdeias,
                    variant = InovagabButtonVariant.Neutral,
                    leadingIcon = Icons.Default.Lightbulb,
                    modifier = Modifier.weight(1f)
                )
                InovagabButton(
                    text = "Ver projetos",
                    onClick = onNavigateToProjetos,
                    leadingIcon = Icons.Default.Folder,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun ConversionRate(
    label: String,
    rate: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = "$rate%",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

// ---------------------------------------------------------------------------
// Section: Financial
// ---------------------------------------------------------------------------

@Composable
private fun FinancialSection(
    investimentoTotal: Double,
    retornoMensal: Double,
    lucroAnualizado: Double,
    isDarkTheme: Boolean,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        SectionHeader(title = stringResource(R.string.dashboard_financeiro))
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FinanceiroMiniCard(
                label = stringResource(R.string.dashboard_investimento),
                value = investimentoTotal,
                isNegative = false,
                isDarkTheme = isDarkTheme,
                modifier = Modifier.weight(1f)
            )
            FinanceiroMiniCard(
                label = stringResource(R.string.dashboard_retorno),
                value = retornoMensal,
                isNegative = false,
                isDarkTheme = isDarkTheme,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        FinanceiroMiniCard(
            label = stringResource(R.string.dashboard_lucro),
            value = lucroAnualizado,
            isNegative = lucroAnualizado < 0,
            isDarkTheme = isDarkTheme,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// ---------------------------------------------------------------------------
// Section: Portfolio execution
// ---------------------------------------------------------------------------

@Composable
private fun PortfolioExecutionSection(
    projetosNoPrazo: Int,
    projetosAtrasados: Int,
    progressoMedioProjetos: Double,
    projetosAtivos: Int,
    isDarkTheme: Boolean,
    onNavigateToProjetos: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier = modifier.fillMaxWidth()) {
        Column {
            SectionHeader(
                title = stringResource(R.string.leader_execucao_carteira),
                subtitle = "$projetosAtivos projetos ativos"
            )
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ExecutionMetric(
                    label = stringResource(R.string.dashboard_no_prazo),
                    value = projetosNoPrazo.toString(),
                    color = SuccessGreen,
                    modifier = Modifier.weight(1f)
                )
                ExecutionMetric(
                    label = stringResource(R.string.dashboard_atrasados),
                    value = projetosAtrasados.toString(),
                    color = if (projetosAtrasados > 0)
                        MaterialTheme.colorScheme.error else SuccessGreen,
                    modifier = Modifier.weight(1f)
                )
                ExecutionMetric(
                    label = stringResource(R.string.leader_progresso_medio),
                    value = "${progressoMedioProjetos.toInt()}%",
                    color = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            InovagabButton(
                text = "Ver todos os projetos",
                onClick = onNavigateToProjetos,
                leadingIcon = Icons.Default.Folder,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ExecutionMetric(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

// ---------------------------------------------------------------------------
// Section: Area participation
// ---------------------------------------------------------------------------

@Composable
private fun AreaParticipationSection(
    areas: List<AreaDesempenhoMetric>,
    isDarkTheme: Boolean,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier = modifier.fillMaxWidth()) {
        Column {
            SectionHeader(
                title = stringResource(R.string.leader_participacao_area),
                subtitle = stringResource(R.string.leader_desempenho_subtitle)
            )
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalBarChart(
                data = areas.map { BarChartData(label = it.label, value = it.value, color = AISpark) },
                showAxisLabels = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Skeleton loading state
// ---------------------------------------------------------------------------

@Composable
private fun LeaderDashboardSkeleton(onNavigateToHome: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        AguiaTopBar(
            title = stringResource(R.string.leader_resumo_executivo),
            onBackClick = onNavigateToHome
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = ScreenPadding.Horizontal),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))
            // Skeleton AI card
            SkeletonLoader(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .clip(RoundedCornerShape(20.dp))
            )
            // Skeleton KPI grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SkeletonMetricCard(modifier = Modifier.weight(1f))
                SkeletonMetricCard(modifier = Modifier.weight(1f))
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SkeletonMetricCard(modifier = Modifier.weight(1f))
                SkeletonMetricCard(modifier = Modifier.weight(1f))
            }
            // Skeleton funnel
            SkeletonLoader(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(20.dp))
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Error state
// ---------------------------------------------------------------------------

@Composable
private fun LeaderDashboardError(
    messageRes: Int,
    onNavigateToHome: () -> Unit,
    onRetry: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        AguiaTopBar(
            title = stringResource(R.string.leader_resumo_executivo),
            onBackClick = onNavigateToHome
        )
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            EmptyState(
                icon = Icons.Default.Info,
                title = stringResource(messageRes),
                subtitle = "",
                actionLabel = stringResource(R.string.leader_retry),
                onActionClick = onRetry
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Animated section helper
// ---------------------------------------------------------------------------

@Composable
private fun AnimatedSection(
    visible: Boolean,
    delayMillis: Int,
    content: @Composable () -> Unit
) {
    var sectionVisible by remember { mutableStateOf(false) }
    LaunchedEffect(visible) {
        if (visible) {
            delay(delayMillis.toLong())
            sectionVisible = true
        }
    }
    AnimatedVisibility(
        visible = sectionVisible,
        enter = fadeIn(animationSpec = tween(300)) + slideInVertically(
            initialOffsetY = { 30 },
            animationSpec = tween(300)
        )
    ) {
        Column { content() }
    }
}

// ---------------------------------------------------------------------------
// Previews
// ---------------------------------------------------------------------------

@Preview(name = "Success — Light")
@Preview(name = "Success — Dark", uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun LeaderDashboardBodyPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            LeaderDashboardBody(
                uiState = LeaderDashboardUiState(
                    insight = DashboardInsight(
                        titulo = "ROI sólido com gargalo na conversão",
                        resumo = "O portfólio conta com 7 ideias ativas e ROI de 28% a.a. Há 2 ideias aprovadas aguardando conversão em projeto.",
                        evidencias = listOf("ROI de 28%", "2 ideias sem projeto", "3 no prazo"),
                        acaoRecomendada = "Converter as 2 ideias aprovadas em projetos.",
                        modelo = "gemini-3.6-flash",
                        isFallback = false,
                        geradoEm = "2026-09-21T21:59Z"
                    ),
                    funil = listOf(
                        FunnelStepMetric("IDEIAS", "Ideias", 7),
                        FunnelStepMetric("APROVADAS", "Aprovadas", 2),
                        FunnelStepMetric("EM_PROJETO", "Em Projeto", 2)
                    ),
                    taxaAprovacaoPercent = 28,
                    taxaConversaoPercent = 100,
                    roiMedio = 28.0,
                    lucroAnualizado = 62_000.0,
                    tempoMedio = 4,
                    totalIdeias = 7,
                    ideiasAprovadas = 2,
                    ideiasEmProjeto = 2,
                    projetosAtivos = 3,
                    investimentoTotal = 220_000.0,
                    retornoMensal = 23_500.0,
                    projetosNoPrazo = 3,
                    projetosAtrasados = 0,
                    progressoMedioProjetos = 45.0,
                    desempenhoAreas = listOf(
                        AreaDesempenhoMetric("Operações", 85f, 6),
                        AreaDesempenhoMetric("Logística", 14f, 1)
                    )
                ),
                orientacoes = emptyList(),
                selectedOrientacaoId = null,
                onFilterSelect = {},
                onNavigateToHome = {},
                onNavigateToIdeias = {},
                onNavigateToProjetos = {}
            )
        }
    }
}

@Preview(name = "Skeleton loading")
@Composable
private fun LeaderDashboardSkeletonPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            LeaderDashboardSkeleton(onNavigateToHome = {})
        }
    }
}

@Preview(name = "Error state")
@Composable
private fun LeaderDashboardErrorPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            LeaderDashboardError(
                messageRes = R.string.error_load_dashboard,
                onNavigateToHome = {},
                onRetry = {}
            )
        }
    }
}

@Preview(name = "Filter applied")
@Composable
private fun LeaderDashboardWithFilterPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            LeaderDashboardBody(
                uiState = LeaderDashboardUiState(
                    isInsightLoading = true,
                    insight = DashboardInsight.vazio,
                    funil = listOf(
                        FunnelStepMetric("IDEIAS", "Ideias", 3),
                        FunnelStepMetric("APROVADAS", "Aprovadas", 1),
                        FunnelStepMetric("EM_PROJETO", "Em Projeto", 1)
                    ),
                    roiMedio = 15.0,
                    lucroAnualizado = 20_000.0,
                    tempoMedio = 6,
                    projetosAtrasados = 1
                ),
                orientacoes = listOf(
                    OrientacaoEstrategica(
                        id = "ori-1",
                        titulo = "Experiência digital do passageiro",
                        descricao = "Modernizar embarque, bilhetagem e comunicação.",
                        categoria = com.gtnix.aguiabranca.domain.model.CategoriaOrientacao.EFICIENCIA_OPERACIONAL,
                        criadoPor = "user-lider"
                    )
                ),
                selectedOrientacaoId = "ori-1",
                onFilterSelect = {},
                onNavigateToHome = {},
                onNavigateToIdeias = {},
                onNavigateToProjetos = {}
            )
        }
    }
}
