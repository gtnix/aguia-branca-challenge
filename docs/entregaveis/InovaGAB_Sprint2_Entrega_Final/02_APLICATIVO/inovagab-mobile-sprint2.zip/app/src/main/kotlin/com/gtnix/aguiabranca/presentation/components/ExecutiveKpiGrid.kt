package com.gtnix.aguiabranca.presentation.components

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.gtnix.aguiabranca.presentation.theme.InovagabTheme
import com.gtnix.aguiabranca.presentation.theme.SuccessGreen

/**
 * Grade 2×2 de KPIs prioritários do Resumo Executivo.
 *
 * Exibe: ROI anualizado, Lucro anualizado, Projetos atrasados, Tempo médio de aprovação.
 * Usa [GradientMetricCard] seguindo o padrão do design system.
 */
@Composable
fun ExecutiveKpiGrid(
    roiPercent: Double,
    lucroAnualizado: Double,
    projetosAtrasados: Int,
    tempoMedioAprovacaoDias: Int,
    onNavigateToProjetos: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isDarkTheme = androidx.compose.foundation.isSystemInDarkTheme()
    val gradientColors = if (isDarkTheme)
        GradientMetricCardDefaults.UnifiedGradientDark
    else
        GradientMetricCardDefaults.UnifiedGradientLight

    val atrasadosColor = if (projetosAtrasados > 0)
        MaterialTheme.colorScheme.error
    else
        SuccessGreen

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            GradientMetricCard(
                title = "ROI Anualizado",
                value = "${roiPercent.toInt()}%",
                icon = Icons.Default.TrendingUp,
                gradientColors = gradientColors,
                accentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f).height(130.dp)
            )
            GradientMetricCard(
                title = "Lucro Anualizado",
                value = formatCurrencyCompact(lucroAnualizado),
                icon = Icons.Default.Folder,
                gradientColors = gradientColors,
                accentColor = SuccessGreen,
                modifier = Modifier.weight(1f).height(130.dp)
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            GradientMetricCard(
                title = "Projetos Atrasados",
                value = projetosAtrasados.toString(),
                icon = if (projetosAtrasados > 0) Icons.Default.Warning else Icons.Default.Folder,
                gradientColors = gradientColors,
                accentColor = atrasadosColor,
                onClick = if (projetosAtrasados > 0 && onNavigateToProjetos != null)
                    onNavigateToProjetos else null,
                modifier = Modifier.weight(1f).height(130.dp)
            )
            GradientMetricCard(
                title = "Tempo Médio Aprovação",
                value = "${tempoMedioAprovacaoDias}d",
                icon = Icons.Default.Schedule,
                gradientColors = gradientColors,
                accentColor = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.weight(1f).height(130.dp)
            )
        }
    }
}

/** Formata valor monetário compacto: R$ 62k, R$ 2,5M etc. */
private fun formatCurrencyCompact(value: Double): String {
    return when {
        kotlin.math.abs(value) >= 1_000_000 ->
            "R$%.1fM".format(value / 1_000_000)
        kotlin.math.abs(value) >= 1_000 ->
            "R$%.0fk".format(value / 1_000)
        else ->
            "R$%.0f".format(value)
    }
}

@Preview(name = "Light Mode — sem atrasos")
@Preview(name = "Dark Mode — sem atrasos", uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun ExecutiveKpiGridNoDelayPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            ExecutiveKpiGrid(
                roiPercent = 28.0,
                lucroAnualizado = 62_000.0,
                projetosAtrasados = 0,
                tempoMedioAprovacaoDias = 4,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}

@Preview(name = "Light Mode — com atrasos")
@Composable
private fun ExecutiveKpiGridWithDelayPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            ExecutiveKpiGrid(
                roiPercent = 28.0,
                lucroAnualizado = 62_000.0,
                projetosAtrasados = 2,
                tempoMedioAprovacaoDias = 7,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}
