package com.gtnix.aguiabranca.data.remote.dto

data class OrientacaoDto(
    val id: String,
    val titulo: String,
    val descricao: String? = null,
    val categoria: String,
    val campanha: String? = null,
    val dataCriacao: String? = null,
    val dataAtualizacao: String? = null,
    val ativo: Boolean = true,
    val criadoPorUserId: String? = null
)
