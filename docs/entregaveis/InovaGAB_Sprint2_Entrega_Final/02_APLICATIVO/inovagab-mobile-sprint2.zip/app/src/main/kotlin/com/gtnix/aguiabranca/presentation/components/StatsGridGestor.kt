package com.gtnix.aguiabranca.presentation.components

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.gtnix.aguiabranca.R
import com.gtnix.aguiabranca.presentation.theme.InovagabTheme
import com.gtnix.aguiabranca.presentation.theme.SuccessGreen

@Composable
fun StatsGridGestor(
    ideiasAvaliadas: Int,
    ideiasAprovadas: Int,
    projetosArea: Int,
    modifier: Modifier = Modifier
) {
    val taxaAprovacaoLabel = if (ideiasAvaliadas > 0) {
        val pct = (ideiasAprovadas.toFloat() / ideiasAvaliadas * 100).toInt().coerceIn(0, 100)
        "$pct%"
    } else {
        stringResource(R.string.perfil_gestor_taxa_aprovacao_indisponivel)
    }

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PerfilIndicatorCard(
            label = stringResource(R.string.perfil_gestor_stat_ideias_avaliadas_card),
            value = ideiasAvaliadas.toString(),
            icon = Icons.Default.RateReview,
            iconAccent = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f)
        )

        PerfilIndicatorCard(
            label = stringResource(R.string.home_metric_engajamento_short),
            value = taxaAprovacaoLabel,
            icon = Icons.AutoMirrored.Filled.TrendingUp,
            iconAccent = SuccessGreen,
            modifier = Modifier.weight(1f)
        )

        PerfilIndicatorCard(
            label = stringResource(R.string.perfil_gestor_stat_projetos_area_card),
            value = projetosArea.toString(),
            icon = Icons.Default.Folder,
            iconAccent = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.weight(1f)
        )
    }
}

@Preview(name = "Light")
@Preview(name = "Dark", uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun StatsGridGestorPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            StatsGridGestor(
                ideiasAvaliadas = 10,
                ideiasAprovadas = 4,
                projetosArea = 5,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}

@Preview(name = "Sem avaliações", showBackground = true)
@Composable
private fun StatsGridGestorEmptyPreview() {
    InovagabTheme {
        Surface(color = MaterialTheme.colorScheme.background) {
            StatsGridGestor(
                ideiasAvaliadas = 0,
                ideiasAprovadas = 0,
                projetosArea = 2,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}
