package com.gtnix.aguiabranca.presentation.screens.orientacoes

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gtnix.aguiabranca.R
import com.gtnix.aguiabranca.domain.model.CategoriaOrientacao
import com.gtnix.aguiabranca.domain.model.OrientacaoEstrategica
import com.gtnix.aguiabranca.presentation.components.AguiaTopBar
import com.gtnix.aguiabranca.presentation.components.EmptyState
import com.gtnix.aguiabranca.presentation.components.SkeletonListPlaceholder
import com.gtnix.aguiabranca.presentation.theme.InovagabTheme
import com.gtnix.aguiabranca.presentation.util.bounceClick
import com.gtnix.aguiabranca.presentation.util.orientacaoCategoriaColor
import com.gtnix.aguiabranca.presentation.util.orientacaoCategoriaIconForList
import com.gtnix.aguiabranca.presentation.util.orientacaoCategoriaShortLabel

@Composable
fun OrientacoesScreen(
    viewModel: OrientacoesViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToNova: () -> Unit,
    onNavigateToEditar: (String) -> Unit = {},
    onNavigateToDetalhe: (String) -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val listState = rememberLazyListState()
    var orientacaoParaExcluir by remember { mutableStateOf<OrientacaoEstrategica?>(null) }

    val isFabVisible by remember {
        derivedStateOf {
            val firstVisibleIndex = listState.firstVisibleItemIndex
            val scrollOffset = listState.firstVisibleItemScrollOffset
            firstVisibleIndex == 0 || scrollOffset <= 0
        }
    }

    LaunchedEffect(uiState.errorMessageRes) {
        uiState.errorMessageRes?.let { messageRes ->
            snackbarHostState.showSnackbar(context.getString(messageRes))
            viewModel.clearError()
        }
    }

    Scaffold(
        topBar = {
            AguiaTopBar(
                title = stringResource(R.string.orientacoes_title),
                onBackClick = onNavigateBack
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        floatingActionButton = {
            if (uiState.isLider) {
                AnimatedVisibility(
                    visible = isFabVisible,
                    enter = scaleIn(),
                    exit = scaleOut()
                ) {
                    FloatingActionButton(
                        onClick = onNavigateToNova,
                        containerColor = MaterialTheme.colorScheme.primary
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = stringResource(R.string.orientacoes_nova)
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        when {
            uiState.isLoading -> {
                SkeletonListPlaceholder(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                )
            }

            uiState.orientacoes.isEmpty() -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyState(
                        icon = Icons.Default.Flag,
                        title = stringResource(R.string.orientacoes_empty_title),
                        subtitle = if (uiState.isLider) {
                            stringResource(R.string.orientacoes_empty_subtitle_lider)
                        } else {
                            stringResource(R.string.orientacoes_empty_subtitle_readonly)
                        }
                    )
                }
            }

            else -> {
                AnimatedVisibility(
                    visible = uiState.orientacoes.isNotEmpty(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(
                            items = uiState.orientacoes,
                            key = { it.id }
                        ) { orientacao ->
                            OrientacaoCard(
                                orientacao = orientacao,
                                showActions = uiState.isLider,
                                onClick = { onNavigateToDetalhe(orientacao.id) },
                                onEditar = { onNavigateToEditar(orientacao.id) },
                                onToggleAtivacao = {
                                    viewModel.toggleAtivacao(orientacao.id, orientacao.ativa)
                                },
                                onExcluir = { orientacaoParaExcluir = orientacao }
                            )
                        }
                    }
                }
            }
        }

        orientacaoParaExcluir?.let { orientacao ->
            AlertDialog(
                onDismissRequest = { orientacaoParaExcluir = null },
                title = { Text(stringResource(R.string.orientacao_excluir_titulo)) },
                text = {
                    Text(
                        stringResource(
                            R.string.orientacao_excluir_mensagem,
                            orientacao.titulo
                        )
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            viewModel.excluirOrientacao(orientacao.id)
                            orientacaoParaExcluir = null
                        }
                    ) {
                        Text(
                            text = stringResource(R.string.orientacao_excluir_confirmar),
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                },
                dismissButton = {
                    TextButton(onClick = { orientacaoParaExcluir = null }) {
                        Text(stringResource(R.string.btn_cancelar))
                    }
                }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OrientacaoCard(
    orientacao: OrientacaoEstrategica,
    showActions: Boolean,
    onClick: () -> Unit,
    onEditar: () -> Unit,
    onToggleAtivacao: () -> Unit,
    onExcluir: () -> Unit
) {
    val isDarkTheme = isSystemInDarkTheme()
    val shape = RoundedCornerShape(16.dp)
    val categoriaAccent = orientacaoCategoriaColor(orientacao.categoria)
    val borderColor = if (isDarkTheme) {
        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)
    } else {
        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
    }
    val containerColor = if (orientacao.ativa) {
        MaterialTheme.colorScheme.surface
    } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = shape,
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isDarkTheme) 0.dp else if (orientacao.ativa) 2.dp else 1.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (!isDarkTheme) Modifier.border(1.dp, borderColor, shape)
                    else Modifier
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .bounceClick(onClick = onClick),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(
                                categoriaAccent.copy(alpha = if (isDarkTheme) 0.18f else 0.12f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = orientacaoCategoriaIconForList(orientacao.categoria),
                            contentDescription = null,
                            tint = categoriaAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = orientacao.titulo,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = orientacao.descricao,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OrientacaoListStatusBadge(ativa = orientacao.ativa)
                    if (showActions) {
                        Row {
                            IconButton(onClick = onEditar, modifier = Modifier.size(36.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = stringResource(R.string.cd_edit_orientacao),
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            IconButton(onClick = onToggleAtivacao, modifier = Modifier.size(36.dp)) {
                                Icon(
                                    imageVector = Icons.Default.PowerSettingsNew,
                                    contentDescription = if (orientacao.ativa) "Desativar" else "Ativar",
                                    tint = if (orientacao.ativa) {
                                        MaterialTheme.colorScheme.secondary
                                    } else {
                                        MaterialTheme.colorScheme.outline
                                    },
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            IconButton(onClick = onExcluir, modifier = Modifier.size(36.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = stringResource(R.string.cd_delete_orientacao),
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            FlowRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .bounceClick(onClick = onClick),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OrientacaoMetaChip(
                    text = orientacaoCategoriaShortLabel(orientacao.categoria),
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                )
                if (orientacao.campanha.isNotBlank()) {
                    OrientacaoMetaChip(
                        text = orientacao.campanha,
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                        contentColor = MaterialTheme.colorScheme.onTertiaryContainer,
                        maxLines = 1
                    )
                }
                PrioridadeMetaChip(prioridade = orientacao.prioridade)
            }
        }
    }
}

@Composable
private fun OrientacaoListStatusBadge(ativa: Boolean) {
    val color = if (ativa) Color(0xFF4CAF50) else MaterialTheme.colorScheme.onSurfaceVariant
    val label = if (ativa) {
        stringResource(R.string.orientacao_ativa)
    } else {
        stringResource(R.string.orientacao_inativa)
    }

    Box(
        modifier = Modifier
            .widthIn(min = 48.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = color,
            maxLines = 1
        )
    }
}

@Composable
private fun OrientacaoMetaChip(
    text: String,
    containerColor: Color,
    contentColor: Color,
    maxLines: Int = 2
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(containerColor)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = contentColor,
            maxLines = maxLines,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun PrioridadeMetaChip(prioridade: Int) {
    val color = when (prioridade) {
        1 -> MaterialTheme.colorScheme.error
        2 -> MaterialTheme.colorScheme.secondary
        else -> MaterialTheme.colorScheme.tertiary
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.TrendingUp,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "P$prioridade",
                style = MaterialTheme.typography.labelSmall,
                color = color,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Preview(showBackground = true, name = "Card LIDER")
@Composable
private fun OrientacaoCardLiderPreview() {
    InovagabTheme {
        OrientacaoCard(
            orientacao = OrientacaoEstrategica(
                id = "1",
                titulo = "Eficiência operacional e experiência do passageiro",
                descricao = "Priorizar iniciativas que reduzam custos logísticos e melhorem NPS.",
                categoria = CategoriaOrientacao.EFICIENCIA_OPERACIONAL,
                prioridade = 3,
                ativa = true,
                criadoPor = "demo-lider",
                campanha = "Águia 2026 — Inovação em Campo"
            ),
            showActions = true,
            onClick = {},
            onEditar = {},
            onToggleAtivacao = {},
            onExcluir = {}
        )
    }
}

@Preview(showBackground = true, name = "Card Read-Only")
@Composable
private fun OrientacaoCardReadOnlyPreview() {
    InovagabTheme {
        OrientacaoCard(
            orientacao = OrientacaoEstrategica(
                id = "1",
                titulo = "Reduzir custos operacionais",
                descricao = "Meta de redução de 15% nos custos de operação até dezembro",
                categoria = CategoriaOrientacao.REDUCAO_CUSTOS,
                prioridade = 1,
                ativa = true,
                criadoPor = "demo-lider"
            ),
            showActions = false,
            onClick = {},
            onEditar = {},
            onToggleAtivacao = {},
            onExcluir = {}
        )
    }
}
